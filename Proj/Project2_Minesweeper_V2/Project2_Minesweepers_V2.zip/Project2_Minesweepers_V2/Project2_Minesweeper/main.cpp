/* 
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on February 5, 2018, 12:13 PM
 * Purpose:  Minesweeper Version 2
 */

//System Libraries
#include <iostream>  //I/O Library
#include <cstdlib>   //Random number Library
#include <ctime>     //Time Library
#include <iomanip>   //Formatting Library
#include <string>    //String Library
#include <fstream>   //File I/O
#include <vector>    //For vector file
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions
const int COLSMAX=24; //2-D array constant
//Function Prototypes

    //Function for creating a board
void flBoard(char [][COLSMAX],int,int,int);
void crBoard(char [][COLSMAX],int,int);

    //Function that will check if all mines are flagged
bool ckAllFg(char [][COLSMAX],char [][COLSMAX], int, int);

    //Function that will check if the given tile is valid or not
bool valid(int, int);

    //Function that will check if the tile that the user choose has a mine
bool ckMine(int, int, char [][COLSMAX]);

    //Function that will check the surrounding tile and give the number of mines
int ckNeigh(int, int, char [][COLSMAX]);

    //Function that will replace a mine to a normal tile when it is the user's
    //first move
void replace(int, int, char [][COLSMAX]);

    //Function that will "pop" the tile surrounding the chosen tile until it 
    //reaches a point where the tile is next to the mine
void popTile(int, int, char [][COLSMAX], char [][COLSMAX]);

    //Function that will read the player list
void read(fstream &,string, string [],int);
    //Function to write the player's names
void write(fstream &,string,vector<char> &,int);
    //Overloaded function to print out the player names during game play
void write(fstream &,string, string [],int);

//Execution Begins Here
int main(int argc, char** argv) {
    //Seed the random number function
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare Variables
    const int ROWSMAX=24;
    const int SIZE=20; //Constant for array
    char myBoard[ROWSMAX][COLSMAX]; //The board that the players will see
    char rlBoard[ROWSMAX][COLSMAX]; //The actual board with the location of mines
    
    int length, //side length of the game board
         mines; //number of mines
    fstream name; //User's Name
    string outFile="name_list.txt";  //Writing down the user's name
    string player[SIZE];
    vector<char> number(SIZE);
    
    write(name,outFile,number,SIZE);
    read(name,outFile,player,SIZE);
    
    //Set difficulty of the game
    cout<<"Please choose the difficulty level."<<endl;
    do{
        cout<<"Enter 1 for Beginner (9X9 Board with 10 mines)"<<endl;
        cout<<"Enter 2 for Intermediate (16X16 Board with 40 mines)"<<endl;
        cout<<"Enter 3 for Advanced (24X24 Board with 99 mines)"<<endl;
        cout<<"Enter 4 to show the player list"<<endl; //Option to show the player list
        cout<<"Enter 5 to end the game"<<endl; //Option to end the game
        
        cin>>length;
    }while(!(length>=1&&length<=5));
    int rows,cols;
    switch(length){
        case 1:rows=cols=9,mines=10;break;
        case 2:rows=cols=15,mines=40;break;
        case 3:rows=cols=24,mines=99;break;
        case 4:write(name,outFile,player,SIZE),exit(0);break;
        default:exit(0);break;
    }
    
    //Fill the array for the board
    flBoard(rlBoard,rows,cols,mines);
    flBoard(myBoard,rows,cols,0);
    
    
    bool gameOvr = false;
    int fstPlay=0; //Number of moves taken set to 0
    int score=0;
    //Main Game-play Loop
    do {
      //Display the board
      //To see the mines, uncomment it
      //crBoard(rlBoard,rows,cols);
      crBoard(myBoard,rows,cols);
    
      //Get input from user.
      int col, row; //Input row and columns for the user
      char move; //Input user's move
      int neiBor; //Checking/Counting the neighboring tiles
      cout<<"Enter your move. (Row and Column followed by "
          <<"'c' for clicking, and 'f' for flagging)"<<endl;
      cin >> row >> col >> move;
      cin.ignore();
      
      //Input Validation
      if(length==1){
          while(row<1&&row>=10&&col<1&&col>=10
                  &&(!(move=='c')||(move=='f'))){
          cout<<"Enter your move. (Row and Column followed by "
          <<"'c' for clicking, and 'f' for flagging)"<<endl;
          cin >> row >> col >> move;
          }
      }
      if(length==2){
          while(row<1&&row>=17&&col<1&&col>=17
                  &&(!(move=='c')||(move=='f'))){
          cout<<"Enter your move. (Row and Column followed by "
          <<"'c' for clicking, and 'f' for flagging)"<<endl;
          cin >> row >> col >> move;
          }
      }
      if(length==3){
          while(row<1&&row>=25&&col<1&&col>=25
                  &&(!(move=='c')||(move=='f'))){
          cout<<"Enter your move. (Row and Column followed by "
          <<"'c' for clicking, and 'f' for flagging)"<<endl;
          cin >> row >> col >> move;
          }
      }
      
      
      //Check if the tile that the user clicked is mine or not.
      if(move=='c'){ 
          //To ensure that the first tile chosen is not a mine
          if(fstPlay==0){
              if (ckMine(row-1,col-1,rlBoard)){
                replace(row-1,col-1,rlBoard);
              }
              fstPlay++;//Add 1 to avoid the loop
          }
          
          ckMine(row-1,col-1,rlBoard);
          if ((ckMine(row-1,col-1,rlBoard)==true)){
              cout<<"You Stepped on a Mine! You Lose!"<<endl;
              gameOvr=true;
          }
          else if ((ckMine(row-1,col-1,rlBoard)==false)){
              neiBor=ckNeigh(row-1,col-1,rlBoard);
              myBoard[row-1][col-1] = '0' + neiBor;
              popTile(row-1,col-1,rlBoard,myBoard);
          }
          score++;
      }
      else if(move=='f'){
          ckMine(row-1,col-1,rlBoard);
          myBoard[row-1][col-1] = 'F';
          
          if( ckAllFg(rlBoard, myBoard, rows, cols) ) {
              cout << "You won!" << endl;
              gameOvr = true;
          }
          score++;
      }
    } while( !gameOvr );
    
    //Exit stage right!
    return 0;
}

void flBoard(char array[][COLSMAX],int rows,int cols,int mines){
    for(int i=0;i<rows;i++){
        for(int j=0;j<cols;j++){
            array[i][j]='-';
        }
    }
    
    //Add mines.
    for(int i=0;i<mines;i++){
        bool minePcd = false; //To check if the tile already has a mine assigned
        do {
          int col = rand()%cols;
          int row = rand()%rows;
          if( array[row][col] == '-') {
            array[row][col] = '*';
            minePcd = true; 
          }
        } while( ! minePcd ); //Will not place a mine if the tile already has mine
    }
}

void crBoard(char array[][COLSMAX],int rows,int cols){
    cout<<endl;
    cout<<"  ";
    for(int n=0;n<cols;n++){
        cout<<setw(2)<<n+1<<" ";
    }
    cout<<endl;
    for(int i=0;i<rows;i++){
        cout<<setw(2)<<i+1<<" ";
        for(int j=0;j<cols;j++){
            cout<<array[i][j]<<"  ";
        }
    cout<<endl;
    }
}

bool ckMine(int row, int col, char array[][COLSMAX]){
    if (array[row][col]=='*'){
        return true;
    }
    else if (!(array[row][col]=='*')){
        return false;
    }
}

int ckNeigh(int row, int col, char array[][COLSMAX]){
    int count=0;
    //Top-Left from tile chosen
    if (valid(row+1,col-1)==true) {
        if( array[row+1][col-1]=='*')
          count++;
    }
    //Top from tile chosen
    if (valid(row+1,col)==true) {
        if (array[row+1][col]=='*'){
            count++;
        }
    }
    //Top-Right from tile chosen
    if (valid(row+1,col+1)==true) {
        if (array[row+1][col+1]=='*'){
            count++;
        }
    }
    //Left from tile chosen
    if (valid(row,col-1)==true) {
        if (array[row][col-1]=='*'){
            count++;
        }
    }
    //Right from tile chosen
    if (valid(row,col+1)==true) {
        if (array[row][col+1]=='*'){
            count++;
        }
    }
    //Down-Left from tile chosen
    if (valid(row-1,col-1)==true) {
        if (array[row-1][col-1]=='*'){
            count++;
        }
    }
    //Down from tile chosen
    if (valid(row-1,col)==true) {
        if (array[row-1][col]=='*'){
            count++;
        }
    }
    //Down-Right from tile chosen
    if (valid(row-1,col+1)==true) {
        if (array[row-1][col+1]=='*'){
            count++;
        }
    }
    return count;
}

bool ckAllFg(char rlBoard[][COLSMAX],
                            char myBoard[][COLSMAX],
                            int rows, int cols)
{
    bool brdClrd = true; //Check to see if all mines are flagged
    for( int r = 0; r < rows && brdClrd; r++ ) {
        for( int c = 0; c < cols && brdClrd; c++ ) {
            if( rlBoard[r][c] == '*' ) {
                if( myBoard[r][c] != 'F' )
                    brdClrd = false;
            }
        }
    }
    
    return brdClrd;
}

bool valid(int row, int col){ //Check to see if the given tile is inside the
                              //game boundaries
    bool valid=false;
    if((row>=0)&&(col>=0)&&(row<=COLSMAX)&&(col<=COLSMAX)){
        valid=true;
    }
    else{
        valid=false;
    }
    return valid;
}

void replace(int row, int col, char rlBoard[][COLSMAX]){
    rlBoard[row][col]='-';
    int colp,rowp;
    do{
        colp=rand()%9;
        rowp=rand()%9;
    }while(!(rlBoard[rowp][colp]=='-'));
    rlBoard[rowp][colp]='*';
}

void popTile(int row, int col, char rlBoard[][COLSMAX], char myBoard[][COLSMAX]){
    int neiBor;
    //Top-Left from tile chosen
    if (valid(row+1,col-1)==true) {
        if(!(rlBoard[row+1][col-1] =='*')){
            neiBor=ckNeigh(row+1,col-1,rlBoard);
            rlBoard[row+1][col-1] = '0' + neiBor;
        }
        if(rlBoard[row+1][col-1]=='0' + neiBor){
            myBoard[row+1][col-1]='0' + neiBor;
        if(rlBoard[row+1][col-1]=='-')
          myBoard[row+1][col-1]='0';
        }
    }
    //Top from tile chosen
    if (valid(row+1,col)==true) {
        if(!(rlBoard[row+1][col] =='*')){
            neiBor=ckNeigh(row+1,col,rlBoard);
            rlBoard[row+1][col] = '0' + neiBor;
        }
        if(rlBoard[row+1][col]=='0' + neiBor){
            myBoard[row+1][col]='0' + neiBor;
        if(rlBoard[row+1][col]=='-')
          myBoard[row+1][col]='0';
        }
    }
    //Top-Right from tile chosen
    if (valid(row+1,col+1)==true) {
        if(!(rlBoard[row+1][col+1] =='*')){
            neiBor=ckNeigh(row+1,col+1,rlBoard);
            rlBoard[row+1][col+1] = '0' + neiBor;
        }
        if(rlBoard[row+1][col+1]=='0' + neiBor){
            myBoard[row+1][col+1]='0' + neiBor;
        if(rlBoard[row+1][col+1]=='-')
          myBoard[row+1][col+1]='0';
        }
    }
    //Left from tile chosen
    if (valid(row,col-1)==true) {
        if(!(rlBoard[row][col-1] =='*')){
            neiBor=ckNeigh(row,col-1,rlBoard);
            rlBoard[row][col-1] = '0' + neiBor;
        }
        if(rlBoard[row][col-1]=='0' + neiBor){
            myBoard[row][col-1]='0' + neiBor;
        if(rlBoard[row][col-1]=='-')
          myBoard[row][col-1]='0';
        }
    }
    //Right from tile chosen
    if (valid(row,col+1)==true) {
        if(!(rlBoard[row][col+1] =='*')){
            neiBor=ckNeigh(row,col+1,rlBoard);
            rlBoard[row][col+1] = '0' + neiBor;
        }
        if(rlBoard[row][col+1]=='0' + neiBor){
            myBoard[row][col+1]='0' + neiBor;
        if(rlBoard[row][col+1]=='-')
          myBoard[row][col+1]='0';
        }
    }
    //Down-Left from tile chosen
    if (valid(row-1,col-1)==true) {
        if(!(rlBoard[row-1][col-1] =='*')){
            neiBor=ckNeigh(row-1,col-1,rlBoard);
            rlBoard[row-1][col-1] = '0' + neiBor;
        }
        if(rlBoard[row-1][col-1]=='0' + neiBor){
            myBoard[row-1][col-1]='0' + neiBor;
        if(rlBoard[row-1][col-1]=='-')
          myBoard[row-1][col-1]='0';
        }
    }
    //Down from tile chosen
    if (valid(row-1,col)==true) {
        if(!(rlBoard[row-1][col] =='*')){
            neiBor=ckNeigh(row-1,col,rlBoard);
            rlBoard[row-1][col] = '0' + neiBor;
        }
        if(rlBoard[row-1][col]=='0' + neiBor){
            myBoard[row-1][col]='0' + neiBor;
        if(rlBoard[row-1][col]=='-')
          myBoard[row-1][col]='0';
        }
    }    //Down-Right from tile chosen
    if (valid(row-1,col+1)==true) {
        if(!(rlBoard[row-1][col+1] =='*')){
            neiBor=ckNeigh(row-1,col+1,rlBoard);
            rlBoard[row-1][col+1] = '0' + neiBor;
        }
        if(rlBoard[row-1][col+1]=='0' + neiBor){
            myBoard[row-1][col+1]='0' + neiBor;
        if(rlBoard[row-1][col+1]=='-')
          myBoard[row-1][col+1]='0';
        }
    }
}
void read(fstream & name,string outfile,string player[],int size){ //string names[],  vector<string> &names
    //Open the file
    name.open(outfile.c_str(),ios::in);
    
    //Read the data from the file
    for(int i=0;i<size;i++){
        //name>>player[i];
        getline( name, player[i] ); //get line from "name" stream, store at player[i], stop reading name at a newline
    }
            
    //Close the file
    name.close();
}

void write(fstream & name,string outfile,vector<char> & player,int size){ 
    //Open the file for writing
    string person;
    name.open(outfile.c_str(), ios::out | ios::app);
    cout<<"Enter Your Name"<<endl;
    getline( cin, person ); //get name from terminal
    name<<person<<"\r\n"<<endl; //store in file
    
    
    //Close the file
    name.close();
}

void write(fstream & name,string outfile, string player[],int size){
    read(name,outfile,player,size); //Read the player list and get the list
    for(int i=0;i<size;i++){        //Printing out the player list
        cout<<player[i]<<endl;
    }
}
