/* 
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on February 5, 2018, 12:13 PM
 * Purpose:  Minesweeper Version 2
 */

//System Libraries
#include <iostream>  //I/O Library
#include <cstdlib>   //Random number Library
#include <ctime>     //Time Library
#include <iomanip>   //Formating Library
#include <cmath>     //Math Library
#include <string>    //String Library
#include <fstream>   //File I/O
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

const int MX_SIDE=25; //2-D array constant
//Function Prototypes
//Function for generating the game board
void board(char[MX_SIDE][MX_SIDE], int);

//Execution Begins Here
int main(int argc, char** argv) {
    //Seed the random number function
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare Variables
    bool gameOvr;     //When game over = true
    char myBoard[MX_SIDE][MX_SIDE], //The board that the players will see
         rlBoard[MX_SIDE][MX_SIDE]; //The actual board with the location of mines
    int length, //side length of the game board
         mines, //number of mines
         level; //Difficulty of the game
    //Initialize Variables
    
    //Set difficulty of he game
    cout<<"Please choose the difficulty level."<<endl;
    cout<<"Enter 1 for Beginner (9X9 Board with 10 mines)"<<endl;
    cout<<"Enter 2 for Intermediate (16X16 Board with 40 mines)"<<endl;
    cout<<"Enter 3 for Advanced (24X24 Board with 99 mines)"<<endl;
    cin>>level;
    if(level==1){
        length=9;
        mines=10;
    }
    else if(level==2){
        length=16;
        mines=40;
    }
    else if(level==3){
        length=24;
        mines=99;
    }
    
    board(myBoard,length);
    //Output data
    
    //Exit stage right!
    return 0;
}

void board(char array[][MX_SIDE], int side){
 for(int n=1;n<=side;n++){
     cout<<"  "<<n;
 }
 cout<<endl;
 for(int i=1;i<=side;i++){
     cout<<i<<" ";
     for(int j=1;j<=side;j++){
         cout<<"*  ";
     }
     cout<<endl;
 }   
}

