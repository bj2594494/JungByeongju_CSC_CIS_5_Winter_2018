/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on January 29, 2018, 11:30 PM
 * Purpose: Create Minesweeper Game
 */

//System Libraries
#include <iostream>  //I/O Library
#include <cstdlib>   //Random number Library
#include <ctime>     //Time Library
#include <iomanip>   //Formating Library
#include <cmath>     //Math Library
#include <string>    //String Library
#include <fstream>   //File I/O
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Seed the random number function
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare Variables
    int n; //Value that will stop do while loop
    float r; //For demonstrating float variable & math library
    string name; //User's Name
    ofstream outFile;  //Writing down the user's name
    
    
    //t for "tile"
    bool t1,t2,t3,t4,t5,t6,t7,t8,t9,t10; //Variables for the mind field that the 
                                         //player cannot see
    
    bool td1,td2,td3,td4,td5,td6,td7,td8,td9,td10; //Variables that will be used  
                                                   //to utilize do while loop
    
    //click case #1 to utilize do while loop
    bool cf1,cf2,cf3,cf4,cf5,cf6,cf7,cf8,cf9,cf10;
    //click case #2 to utilize do while loop
    bool cs1,cs2,cs3,cs4,cs5,cs6,cs7,cs8,cs9,cs10;
    //click case #3 to utilize do while loop
    bool ct1,ct2,ct3,ct4,ct5,ct6,ct7,ct8,ct9,ct10;
    
    //flag case to utilize do while loop
    bool f1,f2,f3,f4,f5,f6,f7,f8,f9,f10;//flag case
    
    int      mine;   //number of mines inputted by the user
    int       num;   //User control input for choosing a tile
    char     click;  //User control input for clicking/flagging the tile 
         
    
    //Initialize Variables
    t1=t2=t3=t4=t5=t6=t7=t8=t9=t10=false;          //initializing to false
    td1=td2=td3=td4=td5=td6=td7=td8=td9=td10=false;//initializing to false
    cf1=cf2=cf3=cf4=cf5=cf6=cf7=cf8=cf9=cf10=false;//initializing to false
    cs1=cs2=cs3=cs4=cs5=cs6=cs7=cs8=cs9=cs10=false;//initializing to false
    ct1=ct2=ct3=ct4=ct5=ct6=ct7=ct8=ct9=ct10=false;//initializing to false
    f1=f2=f3=f4=f5=f6=f7=f8=f9=f10=false;          //initializing to false
    
    n=0;  //initializing to zero
    
    outFile.open("name_list.txt"); //Opening name file
    
    r=4.69;  //square root of my age(22)/ will use for eater egg/ decoration
    r=pow(r,2);
    //set up mines
    cout<<fixed<<setprecision(0);
    cout<<r<<" ^_^ Welcome! Welcome! Welcome! ^_^ "<<r<<endl;      
    cout<<"Welcome to Minesweeper_V1."<<endl;
    cout<<"Please Enter Your Full Name."<<endl;
    getline(cin, name); //Getting user's full name
    outFile<<name;  //Copying names
    outFile.close(); //Closing name file
    cout<<"Hello "<<setw(20)<<name<<"!"<<endl;
    cout<<"Please Enter the number of mines you want to find."<<endl;
    cout<<"Enter a number from 1 to 9."<<endl;
    cin>>mine;
    //Input Validation
    while(mine<1||mine>9){
        cout<<"Invalid Entry. Please try again."<<endl;
        cin>>mine;
    }
    
    //Setting up mines
    for(int i=0;i<mine;i+=0)
    {
        if(t1!=true){               //When tile1 is mine
            if((rand()%10)==0){
                t1=true;
                i++;
            }
        }
        if(i<mine){
            if((rand()%10)==1&&t2!=true){ //When tile2 is mine
            t2=true;
            i++;
            }
        }
        if(i<mine){
            if((rand()%10)==2&&t3!=true){ //When tile3 is mine
            t3=true;
            i++;
            }
        }
        if(i<mine){
            if((rand()%10)==3&&t4!=true){ //When tile4 is mine
            t4=true;
            i++;
            }
        }
        if(i<mine){
            if((rand()%10)==4&&t5!=true){ //When tile5 is mine
            t5=true;
            i++;
            }
        }
        if(i<mine){
            if((rand()%10)==5&&t6!=true){ //When tile6 is mine
            t6=true;
            i++;
            }
        }
        if(i<mine){
            if((rand()%10)==6&&t7!=true){ //When tile7 is mine
            t7=true;
            i++;
            }
        }
        if(i<mine){
            if((rand()%10)==7&&t8!=true){ //When tile8 is mine
            t8=true;
            i++;
            }
        }
        if(i<mine){
            if((rand()%10)==8&&t9!=true){ //When tile9 is mine
            t9=true;
            i++;
            }
        }
        if(i<mine){
            if((rand()%10)==9&&t10!=true){ //When tile10 is mine
            t10=true;
            i++;
            }
        }
    }
    
    //Beginning Game Play
    cout<<endl<<"* * * * * * * * * *"<<endl; //Displaying the game board
    
    //Game process
    
    do{
        //User Input for moves
        cout<<endl<<"Please choose a tile number from 1-10. (Far Left=1, Far Right=10)"<<endl;
        cout<<"And Enter your move. (c=click,f=flag)"<<endl;
        cin>>num>>click;
        //User Valiation
        while(num<1||num>10){
            cout<<"Invalid Entry. Please try again."<<endl;
            cin>>num>>click;
        }
        if(!(click=='f'||click=='c')){
            cout<<"Invalid Entry. Please try again. (Far Left=1, Far Right=10) "
                    "(c=click,f=flag)"<<endl;
            cin>>num>>click;
        }
        
        
        
        //Game Play
        //Tile 1 Gameplay option
        if(td1==false){
            if(num==1&&click=='c'){  //When the user loses
                if(t1==true){
                   td1=true;
                   cout<<endl<<"You Stepped on a Mine! You Lose!!";
                   exit(0);
                }
                else if(t1==false){  //When the tile is mine-free
                    if(t2==true){
                        cout<<"1 ";
                        td1=true;
                        cf1=true;
                    }
                    else{
                        cout<<"O ";
                        td1=true;
                        ct1=true;
                    }
                }
            }
            else if(num==1&&click=='f'){ //When user places a flag
                if(t1==true){
                    cout<<"F ";
                    td1=true;
                    f1=true;
                    n++;
                }
                else if(t1==false){ //When user places a flag
                    td1=true;
                    f1=true;
                    cout<<"F ";
                }
            }
            else{
                cout<<"* ";
            }
        }
        else if(td1==true){
            if(ct1==true){
                cout<<"O ";
            }
            if(cf1==true){
                cout<<"1 ";
            }
            if(f1==true){
                cout<<"F ";
            }
        }

        //Tile 2 Gameplay option
        if(td2==false){
            if(num==2&&click=='c'){ //When the user loses
                if(t2==true){
                   td2=true;
                   cout<<endl<<"You Stepped on a Mine! You Lose!!";
                   exit(0);
                }
                else if(t2==false){ //When the tile is mine-free
                    if(t1==true){
                        cout<<"1 ";
                        td2=true;
                        cf2=true;
                    }
                    else if(t3==true){
                        cout<<"1 ";
                        td2=true;
                        cf2=true;
                    }
                    else if((t1==true)&&(t3==true)){
                        cout<<"2 ";
                        td2=true;
                        cs2=true;
                    }
                    else{
                        cout<<"O ";
                        td2=true;
                        ct2=true;
                    }
                }
            }
            else if(num==2&&click=='f'){ //When user places a flag
                if(t2==true){
                    cout<<"F ";
                    td2=true;
                    f2=true;
                    n++;
                }
                else if(t2==false){ //When user places a flag
                    cout<<"F ";
                    f2=true;
                    td2=true;
                }
            }
            else{
                cout<<"* "; //When the tile is untouched
            }
        }
        else if(td2==true){
            if(ct2==true){
                cout<<"O ";
            }
            if(cf2==true){
                cout<<"1 ";
            }
            if(cs2==true){
                cout<<"2 ";
            }
            if(f2==true){
                cout<<"F ";
            }
        }

        //Tile 3 Gameplay option
        if(td3==false){
            if(num==3&&click=='c'){ //When the user loses
                if(t3==true){
                   td3=true;
                   cout<<endl<<"You Stepped on a Mine! You Lose!!";
                   exit(0);
                   
                }
                else if(t3==false){ //When the tile is mine-free
                    if(t2==true){
                        cout<<"1 ";
                        td3=true;
                        cf3=true;
                    }
                    else if(t4==true){
                        cout<<"1 ";
                        td3=true;
                        cf3=true;
                    }
                    else if((t2==true)&&(t4==true)){
                        cout<<"2 ";
                        td3=true;
                        cs3=true;
                    }
                    else{
                        cout<<"O ";
                        td3=true;
                        ct3=true;
                    }
                }
            }
            else if(num==3&&click=='f'){ //When user places a flag
                if(t3==true){
                    cout<<"F ";
                    td3=true;
                    f3=true;
                    n++;
                }
                else if(t3==false){ //When user places a flag
                    cout<<"F ";
                    td3=true;
                    f3=true;
                }
            }
            else{
                cout<<"* "; //When the tile is untouched
            }
        }
        else if(td3==true){
            if(ct3==true){
                cout<<"O ";
            }
            if(cf3==true){
                cout<<"1 ";
            }
            if(cs3==true){
                cout<<"2 ";
            }
            if(f3==true){
                cout<<"F ";
            }
        }

        //Tile 4 Gameplay option
        if(td4==false){
            if(num==4&&click=='c'){ //When the user loses
                if(t4==true){
                   td4=true;
                   cout<<endl<<"You Stepped on a Mine! You Lose!!";
                   exit(0);
                }
                else if(t4==false){ //When the tile is mine-free
                    if(t3==true){
                        cout<<"1 ";
                        td4=true;
                        cf4=true;
                    }
                    else if(t5==true){
                        cout<<"1 ";
                        td4=true;
                        cf4=true;
                    }
                    else if((t3==true)&&(t5==true)){
                        cout<<"2 ";
                        td4=true;
                        cs4=true;
                    }
                    else{
                        cout<<"O ";
                        td4=true;
                        ct4=true;
                    }
                }
            }
            else if(num==4&&click=='f'){ //When user places a flag
                if(t4==true){
                    cout<<"F ";
                    td4=true;
                    f4=true;
                    n++;
                }
                else if(t4==false){ //When user places a flag
                    cout<<"F ";
                    f4=true;
                    td4=true;
                }
            }
            else{
                cout<<"* "; //When the tile is untouched
            }
        }
        else if(td4==true){
            if(ct4==true){
                cout<<"O ";
            }
            if(cf4==true){
                cout<<"1 ";
            }
            if(cs4==true){
                cout<<"2 ";
            }
            if(f4==true){
                cout<<"F ";
            }
        }

        //Tile 5 Gameplay option
        if(td5==false){
            if(num==5&&click=='c'){ //When the user loses
                if(t5==true){
                   td5=true;
                   cout<<endl<<"You Stepped on a Mine! You Lose!!";
                   exit(0);
                }
                else if(t5==false){ //When the tile is mine-free
                    if(t4==true){
                        cout<<"1 ";
                        td5=true;
                        cf5=true;
                    }
                    else if(t6==true){
                        cout<<"1 ";
                        td5=true;
                        cf5=true;
                    }
                    else if((t4==true)&&(t6==true)){
                        cout<<"2 ";
                        td5=true;
                        cs5=true;
                    }
                    else{
                        cout<<"O ";
                        td5=true;
                        ct5=true;
                    }
                }
            }
            else if(num==5&&click=='f'){ //When user places a flag
                if(t5==true){
                    cout<<"F ";
                    td5=true;
                    f5=true;
                    n++;
                }
                else if(t5==false){ //When user places a flag
                    cout<<"F ";
                    f5=true;
                    td5=true;
                }
            }
            else{
                cout<<"* "; //When the tile is untouched
            }
        }
        else if(td5==true){
            if(ct5==true){
                cout<<"O ";
            }
            if(cf5==true){
                cout<<"1 ";
            }
            if(cs5==true){
                cout<<"2 ";
            }
            if(f5==true){
                cout<<"F ";
            }
        }

        //Tile 6 Gameplay option
        if(td6==false){
            if(num==6&&click=='c'){ //When the user loses
                if(t6==true){
                   td6=true;
                   cout<<endl<<"You Stepped on a Mine! You Lose!!";
                   exit(0);
                }
                else if(t6==false){ //When the tile is mine-free
                    if(t5==true){
                        cout<<"1 ";
                        td6=true;
                        cf6=true;
                    }
                    else if(t7==true){
                        cout<<"1 ";
                        td6=true;
                        cf6=true;
                    }
                    else if((t5==true)&&(t7==true)){
                        cout<<"2 ";
                        td6=true;
                        cs6=true;
                    }
                    else{
                        cout<<"O ";
                        td6=true;
                        ct6=true;
                    }
                }
            }
            else if(num==6&&click=='f'){ //When user places a flag
                if(t6==true){
                    cout<<"F ";
                    td6=true;
                    f6=true;
                    n++;
                }
                else if(t6==false){ //When user places a flag
                    cout<<"F ";
                    td6=true;
                    f6=true;
                }
            }
            else{
                cout<<"* "; //When the tile is untouched
            }
        }
        else if(td6==true){
            if(ct6==true){
                cout<<"O ";
            }
            if(cf6==true){
                cout<<"1 ";
            }
            if(cs6==true){
                cout<<"2 ";
            }
            if(f6==true){
                cout<<"F ";
            }
        }

        //Tile 7 Gameplay option
        if(td7==false){
            if(num==7&&click=='c'){ //When the user loses
                if(t7==true){
                   td7=true;
                   cout<<endl<<"You Stepped on a Mine! You Lose!!";
                   exit(0);
                }
                else if(t7==false){ //When the tile is mine-free
                    if(t6==true){
                        cout<<"1 ";
                        td7=true;
                        cf7=true;
                    }
                    else if(t8==true){
                        cout<<"1 ";
                        td7=true;
                        cf7=true;
                    }
                    else if((t6==true)&&(t8==true)){
                        cout<<"2 ";
                        td7=true;
                        cs7=true;
                    }
                    else{
                        cout<<"O ";
                        td7=true;
                        ct7=true;
                    }
                }
            }
            else if(num==7&&click=='f'){ //When user places a flag
                if(t7==true){
                    cout<<"F ";
                    td7=true;
                    f7=true;
                    n++;
                }
                else if(t7==false){ //When user places a flag
                    cout<<"F ";
                    td7=true;
                    f7=true;
                }
            }
            else{
                cout<<"* "; //When the tile is untouched
            }
        }
        else if(td7==true){
            if(ct7==true){
                cout<<"O ";
            }
            if(cf7==true){
                cout<<"1 ";
            }
            if(cs7==true){
                cout<<"2 ";
            }
            if(f7==true){
                cout<<"F ";
            }
        }

        //Tile 8 Gameplay option
        if(td8==false){
            if(num==8&&click=='c'){ //When the user loses
                if(t8==true){
                   td8=true;
                   cout<<endl<<"You Stepped on a Mine! You Lose!!";
                   exit(0);
                }
                else if(t8==false){ //When the tile is mine-free
                    if(t7==true){
                        cout<<"1 ";
                        td8=true;
                        cf8=true;
                    }
                    else if(t9==true){
                        cout<<"1 ";
                        td8=true;
                        cf8=true;
                    }
                    else if((t7==true)&&(t9==true)){
                        cout<<"2 ";
                        td8=true;
                        cs8=true;
                    }
                    else{
                        cout<<"O ";
                        td8=true;
                        ct8=true;
                    }
                }
            }
            else if(num==8&&click=='f'){ //When user places a flag
                if(t8==true){
                    cout<<"F ";
                    td8=true;
                    f8=true;
                    n++;
                }
                else if(t8==false){ //When user places a flag
                    cout<<"F ";
                    td8=true;
                    f8=true;
                }
            }
            else{
                cout<<"* "; //When the tile is untouched
            }
        }
        else if(td8==true){
            if(ct8==true){
                cout<<"O ";
            }
            if(cf8==true){
                cout<<"1 ";
            }
            if(cs8==true){
                cout<<"2 ";
            }
            if(f8==true){
                cout<<"F ";
            }
        }

        //Tile 9 Gameplay option
        if(td9==false){
            if(num==9&&click=='c'){ //When the user loses
                if(t9==true){
                   td9=true;
                   cout<<endl<<"You Stepped on a Mine! You Lose!!";
                   exit(0);
                }
                else if(t9==false){ //When the tile is mine-free
                    if(t8==true){
                        cout<<"1 ";
                        td9=true;
                        cf9=true;
                    }
                    else if(t10==true){
                        cout<<"1 ";
                        td9=true;
                        cf9=true;
                    }
                    else if((t8==true)&&(t10==true)){
                        cout<<"2 ";
                        td9=true;
                        cs9=true;
                    }
                    else{
                        cout<<"O ";
                        td9=true;
                        ct9=true;
                    }
                }
            }
            else if(num==9&&click=='f'){ //When user places a flag
                if(t9==true){
                    cout<<"F ";
                    td9=true;
                    f9=true;
                    n++;
                }
                else if(t9==false){ //When user places a flag
                    cout<<"F ";
                    td9=true;
                    f9=true;
                }
            }
            else{
                cout<<"* "; //When the tile is untouched
            }
        }
        else if(td9==true){
            if(ct9==true){
                cout<<"O ";
            }
            if(cf9==true){
                cout<<"1 ";
            }
            if(cs9==true){
                cout<<"2 ";
            }
            if(f9==true){
                cout<<"F ";
            }
        }

        //Tile 10 Gameplay option
        if(td10==false){
            if(num==10&&click=='c'){ //When the user loses
                if(t10==true){
                   td10=true;
                   cout<<endl<<"You Stepped on a Mine! You Lose!!";
                   exit(0);
                }
                else if(t10==false){ //When the tile is mine-free
                    if(t9==true){
                        cout<<"1 ";
                        td10=true;
                        cf10=true;
                    }
                    else{
                        cout<<"O ";
                        td10=true;
                        ct10=true;
                    }
                }
            }
            else if(num==10&&click=='f'){ //When user places a flag
                if(t10==true){
                    cout<<"F ";
                    td10=true;
                    f10=true;
                    n++;
                }
                else if(t10==false){ //When user places a flag
                    cout<<"F ";
                    td10=true;
                    f10=true;
                }
            }
            else{
                cout<<"* "; //When the tile is untouched
            }
        }
        else if(td10==true){
            if(ct10==true){
                cout<<"O ";
            }
            if(cf10==true){
                cout<<"1 ";
            }
            if(cs10==true){
                cout<<"2 ";
            }
            if(f10==true){
                cout<<"F ";
            }
        }
    
    }while(n=mine);
    //Output data
    
    //Exit stage right!
    return 0;
}

