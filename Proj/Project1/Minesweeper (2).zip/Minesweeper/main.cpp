/* 
 * File:   main.cpp
 * Author: Dr Mark E. Lehr
 * Created on January 2, 2018, 1:20 PM
 * Purpose:  Create a CSC/CIS 5 Template
 */

//System Libraries
#include <iostream>  //I/O Library
#include <cmath>     //Math Library
#include <iomanip>   //Formatting Library
#include <cstdlib>   //Random Number Generator
#include <ctime>     //Time to seed Random Number
#include <string> 
#include <fstream> 

using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    srand(static_cast<unsigned int>(time(0)));
    //Declare Variables
    char tile,
         mine,
         numTile;
    //Initialize Variables
    tile=10;
    //Generate a mine field
    for(int i=1;i<=tile;i++){
        cout<<"* ";
    }
    
    
    //Exit stage right!
    return 0;
}