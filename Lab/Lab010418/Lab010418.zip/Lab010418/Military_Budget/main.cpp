/* 
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on January 4, 2018, 12:40 PM
 * Purpose:  Calculate percentage of U.S Military Budget
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float FebBuds, // Total Federal Budget in $
          MilBuds,  // Military Budget in $
          MilPerc;  // Percentage of Military Budget 
    //Initialize Variables
    FebBuds=4.1e12;
    MilBuds=6.4e11;
    //Process/Map inputs to outputs
    MilPerc=(MilBuds/FebBuds)*100;
    //Output data
    cout<<"Calculate the percentage of U.S Military Budget"<<endl;
    cout<<"Total Federal Budget = 4.1 Trillion Dollars"<<endl;
    cout<<"Total Military Budget = 640 Billion Dollars"<<endl;
    cout<<"Percentage of Military Budget to Total Budget = ";
    cout<<MilPerc<<"%"<<endl;
    //Exit stage right!
    return 0;
}