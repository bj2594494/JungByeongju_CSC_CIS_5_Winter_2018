/* 
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on January 4, 2018, 1:24 PM
 * Purpose:  Calculate REAL Gas Profits
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float GasPrice, // Costco Gas Price in cent per gallon
          FedTax, // Federal Tax in cent per gallon
          StatTax, // State Tax in cent per gallon
          SlsTax, // Sales Tax in cent per gallon
          OilProf, // Evil Oil Company Profit in cent per gallon  
          TGovPro, // Total Government Profit  
          OilPerc, // Evil Oil Company Profit in percent
          GovPerc; // Government Profit in percent
    //Initialize Variables
    GasPrice = 275;
    FedTax = 18.4;
    StatTax = 36;
    SlsTax = 22;
    OilProf = 18.9;
    //Process/Map inputs to outputs
    TGovPro = FedTax + StatTax + SlsTax;
    OilPerc = (OilProf/GasPrice)*100;
    GovPerc = (TGovPro/GasPrice)*100;
    //Output data
    cout<<"TRUE Gas Profit"<<endl;
    cout<<"Total Government Profit in Cent per Gallon = "<<TGovPro<<endl;
    cout<<"Total Gas Company Profit in Cent per Gallon = "<<OilProf<<endl;
    cout<<"Government Profit in Percent = "<<GovPerc<<"%"<<endl;
    cout<<"Oil Company Profit in Percent = "<<OilPerc<<"%"<<endl;
    //Exit stage right!
    return 0;
}