/* 
 * File:   main.cpp
 * Author: Dr Mark E. Lehr and Byeongju Jung
 * Created on January 30, 2018, 10:20 PM
 * Purpose: Grade a DMV Test
 */

//System Libraries
#include <iostream>
#include <fstream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes
void read(ifstream &,char [],char[],int);
void read(ifstream &,string,char [],int);
int score(char [], char [], int);
void write(ofstream &,string,char [],char [],int);

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    ifstream answer,test;
    const int SIZE=20;
    char ans[SIZE], compare[SIZE];
    
    //Initialize Variables
    char fileName[]="answerkey.dat";
    string testName="test.dat";
    read(answer,fileName,ans,SIZE);
    read(test,testName,compare,SIZE);
    
    //Process/Map inputs and output data
    int correct=score(ans,compare,SIZE);
    cout<<"Correct Answers = "<<correct
            <<" out of "<<SIZE
            <<" with a percentage score = "
            <<100.0f*correct/SIZE<<"%"
            <<endl;
    
    
    //Exit stage right!
    return 0;
}

void write(ofstream & output,string,char ans[],char test[],int n){
    
    //Process/Map inputs and output data
    int correct=score(ans,compare,SIZE);
    cout<<"Correct Answers = "<<correct
            <<" out of "<<SIZE
            <<" with a percentage score = "
            <<100.0f*correct/SIZE<<"%"
            <<endl;
}

int score(char ans[], char test[], int n){
    //Declare and initialize the sum
    int sum=0;
    //Process the data
    for(int i=0;i<n;i++){
        if(ans[i]==test[i])sum++;
    }
}

void read(ifstream & input,string fn,char ans[],int n){
    //Open the file
    input.open(fn);
    
    //Read the data from the file
    for(int i=0;i<n;i++){
        input>>ans[i];
    }
            
    //Close the file
    input.close();
}

void read(ifstream & input,char fn[],char ans[],int n){
    //Open the file
    input.open(fn);
    
    //Read the data from the file
    for(int i=0;i<n;i++){
        input>>ans[i];
    }
            
    //Close the file
    input.close();
}