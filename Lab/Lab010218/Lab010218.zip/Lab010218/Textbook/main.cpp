/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on January 3, 2018, 8:33 PM
 * Purpose: Template created for practicing textbook examples
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main() {
    //Declare Variables
    
    //Initialize Variables
    
    //Process/Map inputs to outputs
    cout << "Success\n";
    cout << "Success";
    cout << " Success\n\n";
    cout << "Success\n";
    
    //Output data
    
    //Exit stage right!
    return 0;
}

