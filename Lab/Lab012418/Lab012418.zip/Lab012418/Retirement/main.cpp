/* 
 * File:   main.cpp
 * Author: Dr Mark E. Lehr and Byeongju Jung
 * Created on January 24, 2018, 1:27 PM
 * Purpose:  Retirement
 */

//System Libraries
#include <iostream>  //I/O Library
#include <iomanip>   //Format Currency
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions
const char PERCENT=100; //Percent Conversion

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float salary, invRate, savReqd, percDep;
    float savings;
    
    //Initialize Variables
    salary=100000.0f;      //Salary in $'s
    invRate=0.05f;         //Investment rate from CA Muni Bonds
    savReqd=salary/invRate;//Savings Required$'s
    percDep=0.10f;         //Percentage Salary Deposited each year
    savings=0.0f;          //Retirement Savings at the start
    
    //Process/Calculations and Display
    cout<<fixed<<setprecision(2)<<showpoint;
    cout<<"Yearly Salary = $"<<salary<<endl;
    cout<<"Municipal Bond Rate = "<<invRate*PERCENT<<"%"<<endl;
    cout<<"Savings Required = $"<<savReqd<<endl;
    cout<<"PErcentage Yearly Deposit = "<<percDep*PERCENT<<"%"<<endl;
    cout<<endl<<"Count Year     Savings  Interest   Deposit"<<endl;
    for(int count=0,year=2022;savings<savReqd;count++,year++){
        float inEndYr=savings*invRate;
        float dpEndYr=salary*percDep;
        cout<<setw(5)<<count
                <<setw(5)<<year
                <<setw(12)<<savings
                <<setw(10)<<inEndYr
                <<setw(10)<<dpEndYr<<endl;
        savings+=(inEndYr+dpEndYr);
    }
    //Output data
    
    //Exit stage right!
    return 0;
}