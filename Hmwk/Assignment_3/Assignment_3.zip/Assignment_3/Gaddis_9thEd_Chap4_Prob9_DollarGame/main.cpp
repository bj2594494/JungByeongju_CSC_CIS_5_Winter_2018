/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on January 17, 2018, 6:57 PM
 * Purpose: Create a change for a dollar game.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    float pennies, //The number of pennies the user will input.
          nickels, //The number of nickels the user will input.
          dimes,   //The number of dimes the user will input.
          quarter, //The number of quarter the user will input.
          chngVle; //The total value of the change the user inputs.
    //Initialize Variables
    cout<<"This is the Change for a Dollar Game."<<endl;
    cout<<"Your total value of the coins must equal one dollar "
        <<"in order for you to win."<<endl;
    cout<<"Enter the number of each coins in following order:"<<endl;
    cout<<"Pennies, Nickels, Dimes, Quarters"<<endl;
    cin>>pennies>>nickels>>dimes>>quarter;
    //Process/Map inputs to outputs
    chngVle = (pennies*.01) + (nickels*.05) + (dimes*.10) + (quarter*.25);
    //Output data
    if(chngVle<1)
        cout<<"Your value is less than one dollar."<<endl;
    else if(chngVle>1)
        cout<<"Your value is more than one dollar."<<endl;
    else
        cout<<"Your value is one dollar! You win!!"<<endl;
    //Exit stage right!
    return 0;
}

