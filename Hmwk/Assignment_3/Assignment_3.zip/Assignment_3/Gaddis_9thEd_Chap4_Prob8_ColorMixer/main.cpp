/* 
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on January 17, 2018, 1:41 PM
 * Purpose:  Mixing Colors
 */

//System Libraries
#include <iostream>
#include <cstdlib>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
     //Declare Variables
            string color1,
                   color2;
    //Input colors
    cout<<"This program mixes the primary colors."<<endl;
    cout<<"Please choose two of the following colors:"<<endl;
    cout<<"Red, Blue, Yellow"<<endl;
    cout<<"Your first color:"<<endl;
    cin>>color1;
    if (!(color1=="Red"||color1=="Blue"||color1=="Yellow"
            ||color1=="red"||color1=="blue"||color1=="yellow")){
        cout<<"Error"<<endl;
        exit(0);
    }
    cout<<"Your second color:"<<endl;
    cin>>color2;
    if (!(color2=="Red"||color2=="Blue"||color2=="Yellow"
            ||color2=="red"||color2=="blue"||color2=="yellow")){
        cout<<"Error"<<endl;
        exit(0);
    }
    //Process/Map inputs to outputs


    //Output data
    if ((color1=="Red"||color1=="red")&&(color2=="Red"||color2=="red"))
        cout<<"Your color is red."<<endl;
    if ((color1=="Red"||color1=="red")&&(color2=="Blue"||color2=="blue"))
        cout<<"Your color is purple."<<endl;
    if ((color1=="Red"||color1=="red")&&(color2=="Yellow"||color2=="yellow"))
        cout<<"Your color is orange."<<endl;

    if ((color1=="Blue"||color1=="blue")&&(color2=="Red"||color2=="red"))
        cout<<"Your color is purple."<<endl;
    if ((color1=="Blue"||color1=="blue")&&(color2=="Blue"||color2=="blue"))
        cout<<"Your color is blue."<<endl;
    if ((color1=="Blue"||color1=="blue")&&(color2=="Yellow"||color2=="yellow"))
        cout<<"Your color is green."<<endl;

    if ((color1=="Yellow"||color1=="yellow")&&(color2=="Red"||color2=="red"))
        cout<<"Your color is orange."<<endl;
    if ((color1=="Yellow"||color1=="yellow")&&(color2=="Blue"||color2=="blue"))
        cout<<"Your color is green."<<endl;
    if ((color1=="Yellow"||color1=="yellow")&&(color2=="Yellow"||color2=="yellow"))
        cout<<"Your color is yellow."<<endl;
    //Exit stage right!
    return 0;
}