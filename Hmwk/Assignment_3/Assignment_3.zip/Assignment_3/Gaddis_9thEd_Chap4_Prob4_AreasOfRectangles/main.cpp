/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on January 17, 2018, 12:32 AM
 * Purpose: Calculating/comparing the areas of two rectangles
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    int lngthA,
          wdthA,
          areaA,
          lngthB,
          wdthB,
          areaB;
    //Input values
    cout<<"This program compares the areas of two rectangles."<<endl;
    cout<<"Enter the length of the first rectangle."<<endl;
    cin>>lngthA;
    cout<<"Enter the width of the first rectangle."<<endl;
    cin>>wdthA;
    cout<<"Enter the length of the second rectangle."<<endl;
    cin>>lngthB;
    cout<<"Enter the width of the second rectangle."<<endl;
    cin>>wdthB;
    //Process/Map inputs to outputs
    areaA = lngthA*wdthA;
    areaB = lngthB*wdthB;
    
    if (areaA>areaB)
        cout<<"The first rectangle is larger than the second rectangle.";
    else if (areaA<areaB)
        cout<<"The second rectangle is larger than the first rectangle.";
    else
        cout<<"Both areas are the same.";
    //Output data
    
    //Exit stage right!
    return 0;
}

