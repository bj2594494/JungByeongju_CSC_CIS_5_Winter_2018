/* 
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on January 17, 2018, 1:20 PM
 * Purpose:  Calculating time.
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float seconds, 
        minutes,
        hours,
        days;
    //Input Values
    cout<<"This programs converts seconds to minutes, hours or days."<<endl;
    cout<<"Enter the seconds you want to convert."<<endl;
    cin>>seconds;
    //Process/Map inputs to outputs
    minutes = seconds / 60;
    hours = seconds / 3600;
    days = seconds / 86400;
    //Output data
    if(seconds>=60&&seconds<3600)
        cout<<"There are "<<minutes<<" minutes in "<<seconds<<" seconds."<<endl;
    
    else if(seconds>=3600&&seconds<86400)
        cout<<"There are "<<hours<<" hours in "<<seconds<<" seconds."<<endl;
    else if(seconds>=86400)
        cout<<"There are "<<days<<" days in "<<seconds<<" seconds."<<endl;
    else 
        cout<<seconds<<" seconds is too small to convert."<<endl;
    
    //Exit stage right!
    return 0;
}