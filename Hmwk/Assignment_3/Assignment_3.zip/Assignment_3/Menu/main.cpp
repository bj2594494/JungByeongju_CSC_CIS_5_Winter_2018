/* 
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on January 17, 2018, 7:24 PM
 * Purpose:  Menu
 */

//System Libraries Here
#include <iostream>  //I/O Library
#include <cstdlib>   //Random number function
#include <iomanip>   //Format Library
#include <cmath>     //Math Library
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare variables
    int probNum;
    
    //Menu with input of choice
    cout<<"Choose from the following Menu"<<endl;
    cout<<"Problem 1 -> Gaddis_9thEd_Chap4_Prob1_MinimumMaximum"<<endl;
    cout<<"Problem 2 -> Gaddis_9thEd_Chap4_Prob2_RomanNumeralConverter"<<endl;
    cout<<"Problem 3 -> Gaddis_9thEd_Chap4_Prob3_MagicDates"<<endl;
    cout<<"Problem 4 -> Gaddis_9thEd_Chap4_Prob4_AreasOfRectangles"<<endl;
    cout<<"Problem 5 -> Gaddis_9thEd_Chap4_Prob5_BMI"<<endl;
    cout<<"Problem 6 -> Gaddis_9thEd_Chap4_Prob6_MassWeight"<<endl;
    cout<<"Problem 7 -> Gaddis_9thEd_Chap4_Prob7_TimeCaculator"<<endl;
    cout<<"Problem 8 -> Gaddis_9thEd_Chap4_Prob8_ColorMixer"<<endl;
    cout<<"Problem 9 -> Gaddis_9thEd_Chap4_Prob9_DollarGame"<<endl;
    cout<<"Type 1 to 9 only"<<endl;
    cin>>probNum;
    
    //Output the results
    switch(probNum){
        case 1: {
            //Declare Variables
            short numberA, //The first number the user will input.
                  numberB; //The second number the user will input.
            //Input values
            cout<<"This program determines which one of the two numbers "
                <<"is smaller and which one is larger."<<endl;
            cout<<"Please enter your first integer number."<<endl;
            cin>>numberA;
            cout<<"Please enter your second integer number."<<endl;
            cin>>numberB;
            //Process/Map inputs to outputs
            if(numberA>numberB)
                cout<<numberA<<" is larger than "<<numberB<<"."<<endl;
            else if(numberB>numberA)
                cout<<numberB<<" is larger than "<<numberA<<"."<<endl;
            else
                cout<<"Two numbers are equal."<<endl;
            break;
        }    
        case 2: {
             //Declare Variables
            short  number; //The number the user will enter.
            string RomNum; //Roman numeral number that will display.
            //Input number
            cout<<"This program converts a number to its Roman numeral version."<<endl;
            cout<<"Please choose a number from one to ten."<<endl;
            cin>>number;
            //Process/Map inputs to outputs
            switch(number){
                case 10:RomNum="X";break;
                case  9:RomNum="IX";break;
                case  8:RomNum="VIII";break;
                case  7:RomNum="VII";break;
                case  6:RomNum="VI";break;
                case  5:RomNum="V";break;
                case  4:RomNum="IV";break;
                case  3:RomNum="III";break;
                case  2:RomNum="II";break;
                case  1:RomNum="I";break;
                default:RomNum="Invalid Value.";
            }
            //Output data
            cout<<RomNum<<endl;
            break;
        }
        case 3: {
           //Declare Variables
            short day,  //The day that the user will enter.
                  month,//The month that the user will enter.
                  year; //The two digit year that the user will enter.

            //Input date
            cout<<"This program will determine if the date is magical or not."<<endl;
            cout<<"Enter a day in numerical form."<<endl;
            cin>>day;
                if (day<1||day>31){
                cout<<"Error. Invalid input."<<endl;
                exit(0);
                }
            cout<<"Enter a month in numerical form."<<endl;
            cin>>month;
                if (month<1||month>12){
                cout<<"Error. Invalid input."<<endl;
                exit(0);
                }
            cout<<"Enter the last two digit of a year."<<endl;
            cin>>year;
                if (year<0||year>99){
                cout<<"Error. Invalid input."<<endl;
                exit(0);
                }
            //Process/Map inputs to outputs

            if (day*month==year)
                cout<<"This date is magical."<<endl;
            else if (!(day*month==year))
                cout<<"This date is not magical."<<endl;
            break;
        }
        case 4: {
            //Declare Variables
            int lngthA,
                  wdthA,
                  areaA,
                  lngthB,
                  wdthB,
                  areaB;
            //Input values
            cout<<"This program compares the areas of two rectangles."<<endl;
            cout<<"Enter the length of the first rectangle."<<endl;
            cin>>lngthA;
            cout<<"Enter the width of the first rectangle."<<endl;
            cin>>wdthA;
            cout<<"Enter the length of the second rectangle."<<endl;
            cin>>lngthB;
            cout<<"Enter the width of the second rectangle."<<endl;
            cin>>wdthB;
            //Process/Map inputs to outputs
            areaA = lngthA*wdthA;
            areaB = lngthB*wdthB;

            if (areaA>areaB)
                cout<<"The first rectangle is larger than the second rectangle.";
            else if (areaA<areaB)
                cout<<"The second rectangle is larger than the first rectangle.";
            else
                cout<<"Both areas are the same."<<endl;
            break;
        }
        case 5: {
            //Declare Variables
            float weight, //user's weight in pounds.
                  height, //user's height in inches.
                  bmiScre;//user's BMI score.
            //Input values
            cout<<"This program calculates BMI score."<<endl;
            cout<<"Enter your weight in pounds."<<endl;
            cin>>weight;
            cout<<"Enter your height in inches."<<endl;
            cin>>height;
            //Process/Map inputs to outputs
            bmiScre = weight * (703 / pow(height,2)); //BMI formula

            //Output data
            cout<<setprecision(3)<<endl;
            cout<<"Your BMI score is "<<bmiScre<<endl;
            if (bmiScre < 18.5)         //Score less than 18.5 is underweight.
                cout<<"You are underweight."<<endl;
            else if (bmiScre > 25)      //Score higher than 25 is overweight.
                cout<<"You are overweight."<<endl;
            else                        //Score that is between 18.5 and 25 is optimal.
                cout<<"You are at optimal weight."<<endl;
            break;
        }
        case 6: {
            //Declare Variables
            float mass,  //The object's mass.
                  weight;//The object's weight.
            //Input values
            cout<<"This program calculates the weight of an object using "
                <<"the object's mass in kilograms."<<endl;
            cout<<"Enter the object's mass in kilograms."<<endl;
            cin>>mass;
            //Process/Map inputs to outputs
            weight = mass * 9.8;

            //Output data
            if(weight>1000) //If the weight more than 1000N, display following message.
                cout<<"The object is too heavy."<<endl;
            else if (weight<10) //If the weight less than 10N, display following message.
                cout<<"The object is too light."<<endl;
            else
                cout<<"The weight of the object is "<<weight<<" Newtons"<<endl;
            break;
        }
        case 7: {
             //Declare Variables
            float seconds, 
                minutes,
                hours,
                days;
            //Input Values
            cout<<"This programs converts seconds to minutes, hours or days."<<endl;
            cout<<"Enter the seconds you want to convert."<<endl;
            cin>>seconds;
            //Process/Map inputs to outputs
            minutes = seconds / 60;
            hours = seconds / 3600;
            days = seconds / 86400;
            //Output data
            if(seconds>=60&&seconds<3600)
                cout<<"There are "<<minutes<<" minutes in "<<seconds<<" seconds."<<endl;

            else if(seconds>=3600&&seconds<86400)
                cout<<"There are "<<hours<<" hours in "<<seconds<<" seconds."<<endl;
            else if(seconds>=86400)
                cout<<"There are "<<days<<" days in "<<seconds<<" seconds."<<endl;
            else 
                cout<<seconds<<" seconds is too small to convert."<<endl;
            break;
        }
        case 8: {
            //Declare Variables
            string color1,
                   color2;
            //Input colors
            cout<<"This program mixes the primary colors."<<endl;
            cout<<"Please choose two of the following colors:"<<endl;
            cout<<"Red, Blue, Yellow"<<endl;
            cout<<"Your first color:"<<endl;
            cin>>color1;
            if (!(color1=="Red"||color1=="Blue"||color1=="Yellow"
                    ||color1=="red"||color1=="blue"||color1=="yellow")){
                cout<<"Error"<<endl;
                exit(0);
            }
            cout<<"Your second color:"<<endl;
            cin>>color2;
            if (!(color2=="Red"||color2=="Blue"||color2=="Yellow"
                    ||color2=="red"||color2=="blue"||color2=="yellow")){
                cout<<"Error"<<endl;
                exit(0);
            }
            //Process/Map inputs to outputs


            //Output data
            if ((color1=="Red"||color1=="red")&&(color2=="Red"||color2=="red"))
                cout<<"Your color is red."<<endl;
            if ((color1=="Red"||color1=="red")&&(color2=="Blue"||color2=="blue"))
                cout<<"Your color is purple."<<endl;
            if ((color1=="Red"||color1=="red")&&(color2=="Yellow"||color2=="yellow"))
                cout<<"Your color is orange."<<endl;

            if ((color1=="Blue"||color1=="blue")&&(color2=="Red"||color2=="red"))
                cout<<"Your color is purple."<<endl;
            if ((color1=="Blue"||color1=="blue")&&(color2=="Blue"||color2=="blue"))
                cout<<"Your color is blue."<<endl;
            if ((color1=="Blue"||color1=="blue")&&(color2=="Yellow"||color2=="yellow"))
                cout<<"Your color is green."<<endl;

            if ((color1=="Yellow"||color1=="yellow")&&(color2=="Red"||color2=="red"))
                cout<<"Your color is orange."<<endl;
            if ((color1=="Yellow"||color1=="yellow")&&(color2=="Blue"||color2=="blue"))
                cout<<"Your color is green."<<endl;
            if ((color1=="Yellow"||color1=="yellow")&&(color2=="Yellow"||color2=="yellow"))
                cout<<"Your color is yellow."<<endl;
            break;
        }
        case 9: {
            //Declare Variables
            float pennies, //The number of pennies the user will input.
                  nickels, //The number of nickels the user will input.
                  dimes,   //The number of dimes the user will input.
                  quarter, //The number of quarter the user will input.
                  chngVle; //The total value of the change the user inputs.
            //Initialize Variables
            cout<<"This is the Change for a Dollar Game."<<endl;
            cout<<"Your total value of the coins must equal one dollar "
                <<"in order for you to win."<<endl;
            cout<<"Enter the number of each coins in following order:"<<endl;
            cout<<"Pennies, Nickels, Dimes, Quarters"<<endl;
            cin>>pennies>>nickels>>dimes>>quarter;
            //Process/Map inputs to outputs
            chngVle = (pennies*.01) + (nickels*.05) + (dimes*.10) + (quarter*.25);
            //Output data
            if(chngVle<1)
                cout<<"Your value is less than one dollar."<<endl;
            else if(chngVle>1)
                cout<<"Your value is more than one dollar."<<endl;
            else
                cout<<"Your value is one dollar! You win!!"<<endl;
            break;
        }
        default:cout<<"You choose to exit"<<endl;
    }
   
    //Exit
    return 0;
}