/* 
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on January 17, 2018, 1:03 PM
 * Purpose:  Calculating weight using mass.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float mass,  //The object's mass.
          weight;//The object's weight.
    //Input values
    cout<<"This program calculates the weight of an object using "
        <<"the object's mass in kilograms."<<endl;
    cout<<"Enter the object's mass in kilograms."<<endl;
    cin>>mass;
    //Process/Map inputs to outputs
    weight = mass * 9.8;
    
    //Output data
    if(weight>1000) //If the weight more than 1000N, display following message.
        cout<<"The object is too heavy."<<endl;
    else if (weight<10) //If the weight less than 10N, display following message.
        cout<<"The object is too light."<<endl;
    else
        cout<<"The weight of the object is "<<weight<<" Newtons"<<endl;
    //Exit stage right!
    return 0;
}