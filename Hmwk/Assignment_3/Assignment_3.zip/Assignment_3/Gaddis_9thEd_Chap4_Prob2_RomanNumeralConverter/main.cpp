/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on January 16, 2018, 10:55 PM
 * Purpose: Converting numbers to Roman numeral using switch function.
 */

//System Libraries
#include <iostream>
#include <string>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    short  number; //The number the user will enter.
    string RomNum; //Roman numeral number that will display.
    //Input number
    cout<<"This program converts a number to its Roman numeral version."<<endl;
    cout<<"Please choose a number from one to ten."<<endl;
    cin>>number;
    //Process/Map inputs to outputs
    switch(number){
        case 10:RomNum="X";break;
        case  9:RomNum="IX";break;
        case  8:RomNum="VIII";break;
        case  7:RomNum="VII";break;
        case  6:RomNum="VI";break;
        case  5:RomNum="V";break;
        case  4:RomNum="IV";break;
        case  3:RomNum="III";break;
        case  2:RomNum="II";break;
        case  1:RomNum="I";break;
        default:RomNum="Invalid Value.";
    }
    //Output data
    cout<<RomNum<<endl;
    //Exit stage right!
    return 0;
}

