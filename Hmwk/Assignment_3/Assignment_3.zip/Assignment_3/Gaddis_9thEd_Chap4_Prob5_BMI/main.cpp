/* 
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on January 17, 2018, 12:44 PM
 * Purpose:  Calculate BMI
 */

//System Libraries
#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float weight, //user's weight in pounds.
          height, //user's height in inches.
          bmiScre;//user's BMI score.
    //Input values
    cout<<"This program calculates BMI score."<<endl;
    cout<<"Enter your weight in pounds."<<endl;
    cin>>weight;
    cout<<"Enter your height in inches."<<endl;
    cin>>height;
    //Process/Map inputs to outputs
    bmiScre = weight * (703 / pow(height,2)); //BMI formula
    
    //Output data
    cout<<setprecision(3)<<endl;
    cout<<"Your BMI score is "<<bmiScre<<endl;
    if (bmiScre < 18.5)         //Score less than 18.5 is underweight.
        cout<<"You are underweight."<<endl;
    else if (bmiScre > 25)      //Score higher than 25 is overweight.
        cout<<"You are overweight."<<endl;
    else                        //Score that is between 18.5 and 25 is optimal.
        cout<<"You are at optimal weight."<<endl;
    //Exit stage right!
    return 0;
}