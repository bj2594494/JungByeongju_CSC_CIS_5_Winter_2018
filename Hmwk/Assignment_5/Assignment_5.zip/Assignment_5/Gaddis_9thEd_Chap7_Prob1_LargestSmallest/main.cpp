/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on February 4, 2018, 5:53 PM
 * Purpose: Largest and smallest array values
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    const int values=10; //Ten values entered by the user.
    int number[values];  //Array for inoputing ten values
    int highest,         //Largest value inputted
         lowest;         //Smallest value inputted
    //Input Values
    cout<<"This Program determines the smallest/largest values."<<endl;
    cout<<"Please enter a 10 integer values."<<endl;
    cin>>number[0];
    cin>>number[1];
    cin>>number[2];
    cin>>number[3];
    cin>>number[4];
    cin>>number[5];
    cin>>number[6];
    cin>>number[7];
    cin>>number[8];
    cin>>number[9];
    
    //Initailize Values
    highest=number[0];
    lowest=number[0];
    
    //Process/Map inputs to outputs
    //largest value
    for(int i=0;i<values;i++){
        if (number[i]>highest)
            highest=number[i];
    }
    
    //smallest value
    for(int i=0;i<values;i++){
        if (number[i]<lowest)
            lowest=number[i];
    }
    //Output data
    cout<<"The largest value is "<<highest<<"."<<endl;
    cout<<"The smallest value is "<<lowest<<"."<<endl;
    //Exit stage right!
    return 0;
}

