/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on February 4, 2018, 5:15 PM
 * Purpose: Safest Driving Area
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

int gtAccdt();
 void fndLow(int, int, int, int, int);

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    int north,   //Accisdents in north region.
        south,   //Accisdents in south region.
        east,    //Accisdents in east region.
        west,    //Accisdents in west region.
        central; //Accisdents in central region.
    
            
    //Initialize Variables
    cout<<"This program determines which region has the lowest accidents"
            <<" for last year."<<endl;
    
    //Data for North
    cout<<"North Region:"<<endl;
    north=gtAccdt();
    
    //Data for South
    cout<<"South Region:"<<endl;
    south=gtAccdt();
    
    //Data for East
    cout<<"East Region:"<<endl;
    east=gtAccdt();
    
    //Data for West
    cout<<"West Region:"<<endl;
    west=gtAccdt();
    
    //Data for Central
    cout<<"Central Region:"<<endl;
    central=gtAccdt();
    //Process/Map inputs to outputs
    
    //Output data
    fndLow(north, south, east, west, central);
    //Exit stage right!
    return 0;
}

int gtAccdt(){
    int accdnt;
    cout<<"Enter the number of automobile accidents reported last year."<<endl;
    cout<<"Do not Enter a Value less than 0."<<endl;
    cin>>accdnt;
    while(accdnt<0){
        cout<<"Invalid Input. Try Again."<<endl;
        cin>>accdnt;
    }
    return accdnt;
}

void fndLow(int a, int b, int c, int d, int e){
    if(a<b&&a<c&&a<d&&a<e){
        cout<<"North Region had the least number of accidents last year."<<endl;
    }
    else if(b<a&&b<c&&b<d&&b<e){
        cout<<"South Region had the least number of accidents last year."<<endl;
    }
    else if(c<b&&c<a&&c<d&&c<e){
        cout<<"East Region had the least number of accidents last year."<<endl;
    }
    else if(d<b&&d<c&&d<a&&d<e){
        cout<<"West Region had the least number of accidents last year."<<endl;
    }
    else{
        cout<<"Central Region had the least number of accidents last year."<<endl;
    }
}

