/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on February 4, 2018, 8:26 PM
 * Purpose: Account Validation
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes
int search (const int[], int, int);
void swap (int &, int &);
int sort (int[], int);

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    const int SIZE = 18;
    int account[SIZE]={
        5658845, 4520125, 7895122, 8777541, 8451277, 1302850,
        8080152, 4562555, 5552012, 5050552, 7825877, 1250255,
        1005231, 6545231, 3852085, 7576651, 7881200, 4581002
    };
    int results, //test for validation
          input; //user input for account validation
    
    //Input values
    cout<<"This program validates whether or not your account number works."
            <<endl;
    cout<<"Please input 7 numbered account number."<<endl;
    cin>>input;
    
    //Initialize Variables
    sort(account, SIZE);
    results = search(account, SIZE, input);
    
    
    //Process/Map inputs to outputs
    if (results==-1){
        cout<<"The number is not valid."<<endl;
    }
    else{
        cout<<"Valid Number."<<endl;
    }
    //Output data
    
    //Exit stage right!
    return 0;
}

int search (const int array[], int size, int value){
    int first=0,
        last=size-1,
        middle,
        psition = -1;
        bool found=false;
        
        while(!found&&first <= last){
            middle = (first+last)/2;
            if(array[middle]==value){
                found=true;
                psition=middle;
            }
            else if (array[middle]>value){
                last=middle-1;
            }
            else{
                first=middle+1;
            }
        }
    
    return psition;
   
}

int sort (int array[], int size){
    int minIndx, minValu;
    
    for(int start=0; start<(size-1);start++)
    {
        minIndx=start;
        minValu=array[start];
        for (int index=start+1;index<size;index++)
        {
            if(array[index]<minValu){
                minValu=array[index];
                minIndx=index;
            }
        }
        swap(array[minIndx], array[start]);
    }
}

void swap (int &a, int &b){
    int temp=a;
    a=b;
    b=temp;
}
