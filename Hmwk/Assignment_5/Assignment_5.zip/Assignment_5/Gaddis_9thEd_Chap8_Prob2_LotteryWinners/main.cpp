/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on February 2, 2018, 1:20 PM
 * Purpose: Create a CSC/CIS 5 Template
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes
int search (const int[], int, int);

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    const int SIZE = 10;
    int number[SIZE]={
        13579, 26791, 26792, 33445, 55555,
        62483, 77777, 79422, 85647, 93121
    };
    int results, //test for validation
          input; //user input for account validation
    
    //Input values
    cout<<"This program validates whether or not you have won the lottery."
            <<endl;
    cout<<"Please this week's 5 digits lottery number."<<endl;
    cin>>input;
    
    //Initialize Variables
    results = search(number, SIZE, input);
    
    
    //Process/Map inputs to outputs
    if (results==-1){
        cout<<"You did not win the lottery."<<endl;
    }
    else{
        cout<<"Congrats! You won!"<<endl;
    }
    //Output data
    
    //Exit stage right!
    return 0;
}

int search (const int array[], int size, int value){
    int index=0;
    int psition=-1;
    bool found = false;
    
    while(index<size&&!found){
        if (array[index] == value){
            found = true;
            psition=index;
        }
        index++;
    }
    return psition;
   
}