/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on February 4, 2018, 7:06 PM
 * Purpose: Chips and Salsa Problem
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes
void big (int[], int);
void small (int[], int);
//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    const int VALUES=5;  //Array Size
    string salsa[VALUES];//Types of salsa
    int jarSold[VALUES]; //Jars sold
    int total; //total sales
    int highest;         //Highest sale
    int  lowest;         //Lowest sale
    
    //Initialize Variables
    salsa[0]='mild';
    salsa[1]='medium';
    salsa[2]='sweet';
    salsa[3]='hot';
    salsa[4]='zesty';
    highest=jarSold[0];
    lowest=jarSold[0];
    //Input Values
    cout<<"This program diplays the sales of each salsa types."<<endl;
    cout<<"Please enter the number of mild salsa sold."<<endl;
    cout<<"Do not enter a negative value."<<endl;
    cin>>jarSold[0];
    while(jarSold[0]<0){
        cout<<"Invalid Entry. Try Again."<<endl;
        cin>>jarSold[0];
    }
    cout<<"Please enter the number of medium salsa sold."<<endl;
    cout<<"Do not enter a negative value."<<endl;
    cin>>jarSold[1];
    while(jarSold[1]<0){
        cout<<"Invalid Entry. Try Again."<<endl;
        cin>>jarSold[1];
    }
    cout<<"Please enter the number of sweet salsa sold."<<endl;
    cout<<"Do not enter a negative value."<<endl;
    cin>>jarSold[2];
    while(jarSold[2]<0){
        cout<<"Invalid Entry. Try Again."<<endl;
        cin>>jarSold[2];
    }
    cout<<"Please enter the number of hot salsa sold."<<endl;
    cout<<"Do not enter a negative value."<<endl;
    cin>>jarSold[3];
    while(jarSold[3]<0){
        cout<<"Invalid Entry. Try Again."<<endl;
        cin>>jarSold[3];
    }
    cout<<"Please enter the number of zesty salsa sold."<<endl;
    cout<<"Do not enter a negative value."<<endl;
    cin>>jarSold[4];
    while(jarSold[4]<0){
        cout<<"Invalid Entry. Try Again."<<endl;
        cin>>jarSold[4];
    }
    //highest sales salsa type
    big(jarSold, VALUES);
    //lowest sales salsa type
    small (jarSold, VALUES);
    
    
    //Process/Map inputs to outputs
    total=jarSold[0]+jarSold[1]+jarSold[2]+jarSold[3]+jarSold[4];
    //highest sales salsa type
    
    
    
    
    //Output data
    cout<<"For mild salsa, you sold "<<jarSold[0]<<" jars."<<endl;
    cout<<"For medium salsa, you sold "<<jarSold[1]<<" jars."<<endl;
    cout<<"For sweet salsa, you sold "<<jarSold[2]<<" jars."<<endl;
    cout<<"For hot salsa, you sold "<<jarSold[3]<<" jars."<<endl;
    cout<<"For zesty salsa, you sold "<<jarSold[4]<<" jars."<<endl;
    cout<<"In total, you sold "<<total<<" jars."<<endl;
    //Exit stage right!
    return 0;
}

void big(int array[], int size){
    
    float biggest=0;
    for(int i=0;i<size;i++){
        if (array[i]>biggest)
            biggest=array[i];
    }
    if(array[0]==biggest){
        cout<<"The mild salsa had the largest sales."<<endl; 
    }
    if(array[1]==biggest){
        cout<<"The medium salsa had the largest sales."<<endl; 
    }
    if(array[2]==biggest){
        cout<<"The sweet salsa had the largest sales."<<endl; 
    }
    if(array[3]==biggest){
        cout<<"The hot salsa had the largest sales."<<endl; 
    }
    if(array[4]==biggest){
        cout<<"The zesty salsa had the largest sales."<<endl; 
    }
    
}

void small (int array[], int size){
    float smllest=array[0];
    for(int i=0;i<size;i++){
        if (array[i]<smllest)
            smllest=array[i];
    }
    if(array[0]==smllest){
        cout<<"The mild salsa had the smallest sales."<<endl; 
    }
    if(array[1]==smllest){
        cout<<"The medium salsa had the smallest sales."<<endl; 
    }
    if(array[2]==smllest){
        cout<<"The sweet salsa had the smallest sales."<<endl; 
    }
    if(array[3]==smllest){
        cout<<"The hot salsa had the smallest sales."<<endl; 
    }
    if(array[4]==smllest){
        cout<<"The zesty salsa had the smallest sales."<<endl; 
    }
}