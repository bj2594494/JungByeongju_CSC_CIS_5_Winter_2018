/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on February 4, 2018, 6:15 PM
 * Purpose: Rainfall Statistics
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes
float big (float[], int);
float small (float[], int);
//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    const int values=12;
    float rains[values],
          total,
          average,
          largest,
          lowest;
    //Initialize Variables
    total=0;
    
    //Input values
    cout<<"This program calculates the total rainfall and the average rainfall,"
            <<" and the highest amount of rain and the lowest amount of rain"
            <<" for the year."
            <<endl;

    cout<<"Enter the amount of rainfall in month 1 in inches."<<endl;
    cout<<"Do not Enter a negative value."<<endl;
        
    cin>>rains[0];
    while(rains[0]<0){
        cout<<"Invalid Value. Try Again."<<endl;
        cin>>rains[0];
    }
    
    cout<<"Enter the amount of rainfall in month 2 in inches."<<endl;
    cout<<"Do not Enter a negative value."<<endl;
    cin>>rains[1];
    while(rains[1]<0){
        cout<<"Invalid Value. Try Again."<<endl;
        cin>>rains[1];
    }
    
    cout<<"Enter the amount of rainfall in month 3 in inches."<<endl;
    cout<<"Do not Enter a negative value."<<endl;
    cin>>rains[2];
    while(rains[2]<0){
        cout<<"Invalid Value. Try Again."<<endl;
        cin>>rains[2];
    }
    
    cout<<"Enter the amount of rainfall in month 4 in inches."<<endl;
    cout<<"Do not Enter a negative value."<<endl;
    cin>>rains[3];
    while(rains[3]<0){
        cout<<"Invalid Value. Try Again."<<endl;
        cin>>rains[3];
    }
    
    cout<<"Enter the amount of rainfall in month 5 in inches."<<endl;
    cout<<"Do not Enter a negative value."<<endl;
    cin>>rains[4];
    while(rains[4]<0){
        cout<<"Invalid Value. Try Again."<<endl;
        cin>>rains[4];
    }
    
    cout<<"Enter the amount of rainfall in month 6 in inches."<<endl;
    cout<<"Do not Enter a negative value."<<endl;
    cin>>rains[5];
    while(rains[5]<0){
        cout<<"Invalid Value. Try Again."<<endl;
        cin>>rains[5];
    }
    
    cout<<"Enter the amount of rainfall in month 7 in inches."<<endl;
    cout<<"Do not Enter a negative value."<<endl;
    cin>>rains[6];
    while(rains[6]<0){
        cout<<"Invalid Value. Try Again."<<endl;
        cin>>rains[6];
    }
    
    cout<<"Enter the amount of rainfall in month 8 in inches."<<endl;
    cout<<"Do not Enter a negative value."<<endl;
    cin>>rains[7];
    while(rains[7]<0){
        cout<<"Invalid Value. Try Again."<<endl;
        cin>>rains[7];
    }
    
    cout<<"Enter the amount of rainfall in month 9 in inches."<<endl;
    cout<<"Do not Enter a negative value."<<endl;
    cin>>rains[8];
    while(rains[8]<0){
        cout<<"Invalid Value. Try Again."<<endl;
        cin>>rains[8];
    }
    
    cout<<"Enter the amount of rainfall in month 10 in inches."<<endl;
    cout<<"Do not Enter a negative value."<<endl;
    cin>>rains[9];
    while(rains[9]<0){
        cout<<"Invalid Value. Try Again."<<endl;
        cin>>rains[9];
    }
    
    cout<<"Enter the amount of rainfall in month 11 in inches."<<endl;
    cout<<"Do not Enter a negative value."<<endl;
    cin>>rains[10];
    while(rains[10]<0){
        cout<<"Invalid Value. Try Again."<<endl;
        cin>>rains[10];
    }
    
    cout<<"Enter the amount of rainfall in month 12 in inches."<<endl;
    cout<<"Do not Enter a negative value."<<endl;
    cin>>rains[11];
    while(rains[11]<0){
        cout<<"Invalid Value. Try Again."<<endl;
        cin>>rains[11];
    }
 
    //Process/Map inputs to outputs
    //Total Rains
    for (int t=0;t<values;t++){
        total+=rains[t];
    }
    
    //Average Rainfall
    average=total/values;
    
    //largest value
    largest=big(rains,values);
    
    //smallest value
    lowest=small(rains,values);
    
    //Output data
    cout<<fixed<<setprecision(2);
    cout<<"The total amount of rainfall is "<<total<<" inches."<<endl;
    cout<<"The average rainfall is         "<<average<<" inches."<<endl;
    cout<<"The largest rainfall is         "<<largest<<" inches."<<endl;
    cout<<"The smallest rainfall is        "<<lowest<<" inches."<<endl;
    //Exit stage right!
    return 0;
}

float big (float array[], int size){
    float rains=0;
    for(int l=0;l<size;l++){
        if (array[l]>rains)
            rains=array[l];
    }
    return rains;
}

float small (float array[], int size){
    float lowRain=array[0];
    for(int l=0;l<size;l++){
        if (array[l]<lowRain)
            lowRain=array[l];
    }
    return lowRain;
}
