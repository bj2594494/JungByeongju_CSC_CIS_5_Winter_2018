/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on February 4, 2018, 7:55 PM
 * Purpose: Larger than N Problem
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes
void greater(int[], int, int);
//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    int ARRAYSZ; //Array Size
    int array[ARRAYSZ]; //An Array
    int n; //Number n
    //Input Values
    cout<<"This program solves the Larger than N problem."<<endl;
    cout<<"Please enter the desired array size"<<endl;
    cin>>ARRAYSZ;
    cout<<"Please enter the value of number n."<<endl;
    cin>>n;
    cout<<"Please fill in the array with integers."<<endl;
    for(int i=0;i<ARRAYSZ;i++){
        cin>>array[i];
    }
    
    greater(array,ARRAYSZ,n);
    
    //Process/Map inputs to outputs
   
    //Output data
    
    //Exit stage right!
    return 0;
}

void greater(int array[], int size, int number){
    cout<<"These are greater than n."<<endl;
    for (int s=0;s<size;s++){
        if((array[s])>number){
            cout<<(array[s])<<" ";
        }
    }
}

