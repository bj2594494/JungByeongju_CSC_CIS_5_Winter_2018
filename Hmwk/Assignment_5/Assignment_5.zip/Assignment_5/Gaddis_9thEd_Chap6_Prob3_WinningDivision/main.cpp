/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on February 2, 2018, 4:38 PM
 * Purpose: Winning Division Problem
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes
float gtSales();
 void fndHigh(float, float, float, float);

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    float nEast, //Quarterly Sales figures for NorthEast
          sEast, //Quarterly Sales figures for SouthEast
          nWest, //Quarterly Sales figures for NorthWest
          sWest; //Quarterly Sales figures for SouthWest
    
            
    //Initialize Variables
    cout<<"This program determines which division had the greastest sales"
            <<" for a quarter."<<endl;
    
    //Data for NorthEast
    cout<<"Northeast Division:"<<endl;
    nEast=gtSales();
    
    //Data for SouthEast
    cout<<"SouthEast Division:"<<endl;
    sEast=gtSales();
    
    //Data for NorthWest
    cout<<"NorthWest Division:"<<endl;
    nWest=gtSales();
    
    //Data for SouthWest
    cout<<"SouthWest Division:"<<endl;
    sWest=gtSales();
    //Process/Map inputs to outputs
    
    //Output data
    fndHigh(nEast, sEast, nWest, sWest);
    //Exit stage right!
    return 0;
}

float gtSales(){
    float sales;
    cout<<"Enter quarterly sales figure."<<endl;
    cout<<"Do not Enter a Value less than 0."<<endl;
    cin>>sales;
    while(sales<0){
        cout<<"Invalid Input. Try Again."<<endl;
        cin>>sales;
    }
    return sales;
}

void fndHigh(float a, float b, float c, float d){
    if(a>b&&a>c&&a>d){
        cout<<"NorthEast has greatest sales for the quarter."<<endl;
    }
    else if(b>a&&b>c&&b>d){
        cout<<"SouthEast has greatest sales for the quarter."<<endl;
    }
    else if(c>b&&c>a&&c>d){
        cout<<"NorthWest has greatest sales for the quarter."<<endl;
    }
    else if(d>b&&d>c&&d>a){
        cout<<"SouthWest has greatest sales for the quarter."<<endl;
    }
}

