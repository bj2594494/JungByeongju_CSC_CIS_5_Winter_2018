/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on February 4, 2018, 5:30 PM
 * Purpose: Falling Distance
 */

//System Libraries
#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes
float fallDst(float, float);
//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    float   distnce,   //Falling distance in meters
            gravity;   //Gravity 
    int     time;      //Falling time in seconds
     
    //Initialize Variables and Input data
    gravity=9.8;
    
    cout<<"This Program calculates the falling distance of an object."<<endl;
    cout<<"Please enter the amount of time that the object was falling"
            <<" in seconds."<<endl;
    cin>>time;
    
    //Process/Map inputs to outputs
    
    //Output data
    cout<<fixed<<setprecision(2);
    for(int i=1;i<=10;i++){
        cout<<"In "<<i<<" second(s), the object fell "<<fallDst(i,gravity)
                <<" meters"<<endl;
    }
    cout<<"In "<<time<<" second(s), the object fell "<<fallDst(time,gravity)
            <<" meters"<<endl;
    //Exit stage right!
    return 0;
}

float fallDst(float t, float g){
    float dstance;
    dstance=(.5)*g*pow(t,2);
    return dstance;
}
