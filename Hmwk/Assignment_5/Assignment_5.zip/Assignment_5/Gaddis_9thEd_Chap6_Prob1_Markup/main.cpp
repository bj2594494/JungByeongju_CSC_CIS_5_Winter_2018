/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on February 4, 2018, 4:12 PM
 * Purpose: Markup percentage and wholesale cost
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes
float calRtal(float, float);
//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    float whlSale, //wholesale cost
           markup, //markup percentage
           retail; //retail price
    //Input data
    cout<<"This program calculates retail price."<<endl;
    cout<<"Please enter the wholesale cost of the item."<<endl;
    cout<<"Do not enter a negative value."<<endl;
    cin>>whlSale;
    while(whlSale<0){
        cout<<"Invalid Input. Please Try Again."<<endl;
        cin>>whlSale;
    }
    cout<<"Please enter the markup percentage of the item."<<endl;
    cout<<"Do not enter a negative value."<<endl;
    cin>>markup;
    while(markup<0){
        cout<<"Invalid Input. Please Try Again."<<endl;
        cin>>markup;
    }
    
    //Process/Map inputs to outputs
    retail=calRtal(whlSale,markup);
    //Output data
    cout<<fixed<<setprecision(2);
    cout<<"Your retail cost is $"<<retail<<endl;
    //Exit stage right!
    return 0;
}

float calRtal(float sale, float percent){
    return sale+(sale*percent*.01);
}

