/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on February 4, 2018, 8:26 PM
 * Purpose: Account Validation
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes
int search (const int[], int, int);

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    const int SIZE = 18;
    int account[SIZE]={
        5658845, 4520125, 7895122, 8777541, 8451277, 1302850,
        8080152, 4562555, 5552012, 5050552, 7825877, 1250255,
        1005231, 6545231, 3852085, 7576651, 7881200, 4581002
    };
    int results, //test for validation
          input; //user input for account validation
    
    //Input values
    cout<<"This program validates whether or not your account number works."
            <<endl;
    cout<<"Please input 7 numbered account number."<<endl;
    cin>>input;
    
    //Initialize Variables
    results = search(account, SIZE, input);
    
    
    //Process/Map inputs to outputs
    if (results==-1){
        cout<<"The number is not valid."<<endl;
    }
    else{
        cout<<"Valid Number."<<endl;
    }
    //Output data
    
    //Exit stage right!
    return 0;
}

int search (const int array[], int size, int value){
    int index=0;
    int psition=-1;
    bool found = false;
    
    while(index<size&&!found){
        if (array[index] == value){
            found = true;
            psition=index;
        }
        index++;
    }
    return psition;
   
}
