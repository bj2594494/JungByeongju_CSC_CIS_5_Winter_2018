/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on January 16, 2018, 11:26 PM
 * Purpose: Calculating the magic date.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    short day,  //The day that the user will enter.
          month,//The month that the user will enter.
          year; //The two digit year that the user will enter.
    
    //Input date
    cout<<"This program will determine if the date is magical or not."<<endl;
    cout<<"Enter a day in numerical form."<<endl;
    cin>>day;
    cout<<"Enter a month in numerical form."<<endl;
    cin>>month;
    cout<<"Enter the last two digit of a year."<<endl;
    cin>>year;
    
    //Process/Map inputs to outputs
    
    if (day*month==year)
        cout<<"This date is magical."<<endl;
    else if (!(day*month==year))
        cout<<"This date is not magical."<<endl;
        
    //Output data
    
    //Exit stage right!
    return 0;
}

