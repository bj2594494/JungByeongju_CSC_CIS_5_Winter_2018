/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on January 16, 2018, 10:30 PM
 * Purpose: Determine the smaller number and the larger number.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    short numberA, //The first number the user will input.
          numberB; //The second number the user will input.
    //Input values
    cout<<"This program determines which one of the two numbers "
        <<"is smaller and which one is larger."<<endl;
    cout<<"Please enter your first integer number."<<endl;
    cin>>numberA;
    cout<<"Please enter your second integer number."<<endl;
    cin>>numberB;
    //Process/Map inputs to outputs
    if(numberA>numberB)
        cout<<numberA<<" is larger than "<<numberB<<"."<<endl;
    else if(numberB>numberA)
        cout<<numberB<<" is larger than "<<numberA<<"."<<endl;
    else
        cout<<"Two numbers are equal."<<endl;
    //Output data
    
    //Exit stage right!
    return 0;
}

