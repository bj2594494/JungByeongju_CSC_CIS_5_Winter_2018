/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on January 11, 2018, 9:43 PM
 * Purpose: Calculating the number of widgets.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    float palWght, // The weight of the pallet.
          wdgWght, // The weight of the widgets.
          ttlWght, // The total weight of pallet with the weight of widgets.
          numWdgt; // The number of widget.
    //Input the weights
    cout<<"This program calculates the amount of widgets on a pallet."<<endl;
    cout<<"Please enter the weight of the pallet in pounds."<<endl;
    cin>>palWght;
    cout<<"Please enter the total weight with the widgets on in pounds."<<endl;
    cin>>ttlWght;
    //Process/Map inputs to outputs
    wdgWght = ttlWght - palWght; // The weight of the widgets present on the pallet.
    numWdgt = wdgWght / 12.5;    // Each widgets is 12.5 pounds.
    //Output data
    cout<<"There are "<<numWdgt<<" widgets."<<endl;
    //Exit stage right!
    return 0;
}

