/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on January 10, 2018, 10:31 PM
 * Purpose: Calculating profits for movie tickets
 */

//System Libraries
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    string movie; // The name of the movie.
    float adltTck,  // The number of adult tickets sold.
        chldTck,  // The number of child tickets sold.
        grssPro,  // The gross Box Office profit.
        netPro,   // The net Box Office profit.
        DistPro;  // The amount paid to the distributor.
    //Input tickets sold
    cout<<"This program calculates the profit of a movie."<<endl;
    cout<<"Please enter the name of the movie."<<endl;
    getline(cin, movie);
    cout<<"Please enter the number of adult tickets sold."<<endl;
    cin>>adltTck;
    cout<<"Please enter the number of child tickets sold."<<endl;
    cin>>chldTck;
    //Process/Map inputs to outputs
    grssPro = (adltTck*10)+(chldTck*6); //$10 for adult ticket, $6 for child ticket.
    netPro = grssPro*.2;                //The Box Office takes 20% of the profit.
    DistPro = grssPro-netPro;           //The rest goes to the distributor.
    //Output data
    
    cout<<"Movie Name:                     "<<movie<<endl;
    cout<<"Adult Tickets Sold:               "<<adltTck<<endl;
    cout<<"Child Tickets Sold:               "<<chldTck<<endl;
    cout<<fixed<<setprecision(2)<<showpoint;
    cout<<"Gross Box Office Profit:        $"<<setw(7)<<grssPro<<endl;
    cout<<"Net Box Office Profit:          $"<<setw(7)<<netPro<<endl;
    cout<<"Amount Paid to Distributor:     $"<<setw(7)<<DistPro<<endl;
    //Exit stage right!
    return 0;
}

