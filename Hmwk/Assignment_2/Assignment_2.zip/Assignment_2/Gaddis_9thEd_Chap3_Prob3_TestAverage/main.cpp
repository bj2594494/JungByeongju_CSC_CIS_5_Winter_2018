/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on January 9, 2018, 11:20 PM
 * Purpose: Calculating the test average.
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    float TestA, TestB, TestC, TestD, TestE, // Five test scores.
        AvgTest; // Average of the five test scores.
    //Input test scores
    cout<<"This program calculates the average score of five test scores."<<endl;
    cout<<"Enter your first test score."<<endl;
    cin>>TestA;
    cout<<"Enter your second test score."<<endl;
    cin>>TestB;
    cout<<"Enter your third test score."<<endl;
    cin>>TestC;
    cout<<"Enter your fourth test score."<<endl;
    cin>>TestD;
    cout<<"Enter your fifth test score."<<endl;
    cin>>TestE;
    
    //Process/Map inputs to outputs
    AvgTest = (TestA + TestB + TestC + TestD + TestE) / 5;
    //Output data
    cout<<fixed<<setprecision(1)<<showpoint;
    cout<<"Your average score = "<<AvgTest<<endl;
    //Exit stage right!
    return 0;
}

