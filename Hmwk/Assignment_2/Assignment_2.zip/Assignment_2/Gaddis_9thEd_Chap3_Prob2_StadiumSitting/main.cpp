/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on January 9, 2018, 10:54 PM
 * Purpose: Calculating income generated from ticket sales.
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    
    int ClassA, ClassB, ClassC; // The number of sales for each tickets
                                // Where A=$15, B=$12, C=$9
    float income; //The income generated from ticket sales
        
    //Initialize Variables
    
    //Input number of sales from each tickets
    
    cout<<"This program calculates the total income generated from"
            <<" three different types of tickets."<<endl;
    cout<<"Enter the number of sales from Class A tickets."<<endl;
    cin>>ClassA;
    cout<<"Enter the number of sales from Class B tickets."<<endl;
    cin>>ClassB;
    cout<<"Enter the number of sales from Class C tickets."<<endl;
    cin>>ClassC;
    
    //Process/Map inputs to outputs
    
    income = (ClassA*15)+(ClassB*12)+(ClassC*9);
    
    //Output data
    
    cout<<fixed<<setprecision(2)<<showpoint;
    cout<<"The total income = $"<<income<<endl;
    
    //Exit stage right!
    return 0;
}

