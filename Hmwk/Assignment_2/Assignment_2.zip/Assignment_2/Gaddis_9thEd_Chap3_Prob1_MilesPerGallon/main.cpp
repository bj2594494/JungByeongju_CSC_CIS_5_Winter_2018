/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on January 9, 2018, 10:12 PM
 * Purpose: Calculating miles per gallon
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    float numGlln, //number of gallons of gas the car can hold.
          numMile, //number of miles the car can drive w/ full tank.
          mlsGlln; //number of miles that may be driven per gallons of gas.
    //Initialize Variables
    //Input gallons and miles
    cout<<"This program calculates the gas mileage."<<endl;
    cout<<"Please enter the number of gallons of gas the car can hold."<<endl;
    cin>>numGlln;
    cout<<"Please enter the number of miles the car can drive with a full tank."
            <<endl;
    cin>>numMile;
    //Process/Map inputs to outputs
    mlsGlln = numMile / numGlln;
    //Output data
    cout<<fixed<<setprecision(2)<<endl;
    cout<<"Your gas mileage = "<<mlsGlln<<" miles per gallon."<<endl;
    //Exit stage right!
    return 0;
}

