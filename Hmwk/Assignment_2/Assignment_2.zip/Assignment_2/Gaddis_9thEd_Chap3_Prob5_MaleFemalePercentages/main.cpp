/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on January 10, 2018, 9:45 PM
 * Purpose: Calculating the percentage of males and females in the class.
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    float numMale, // The number of males in the class.
          perMale, // The percentage of males in the class.
          numFmle, // The number of females in the class.
          perFmle, // The percentage of females in the class.
          numTtl;  // The total number of students in the class.
          
    //Input the number of males and females
    cout<<"This program calculates the percentage of males and females "
            <<"in the class."<<endl;
    cout<<"Please enter the number of males in the class."<<endl;
    cin>>numMale;
    cout<<"Please enter the number of females in the class."<<endl;
    cin>>numFmle;
    //Process/Map inputs to outputs
    numTtl = numMale + numFmle;
    perMale = (numMale / numTtl)*100;
    perFmle = (numFmle / numTtl)*100;
    //Output data
    cout<<fixed<<setprecision(1);
    cout<<"The percentage of males in the class    = "<<perMale<<"%"<<endl;
    cout<<"The percentage of females in the class  = "<<perFmle<<"%"<<endl;
    //Exit stage right!
    return 0;
}

