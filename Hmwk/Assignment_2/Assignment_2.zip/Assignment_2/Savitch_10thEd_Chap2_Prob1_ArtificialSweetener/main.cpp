/* 
 * File:   main.cpp
 * Author: Byeongju Jung, Daisy Garsia-Osorio, and Eli Andrade
 * Created on January 10, 2018, 12:38 PM
 * Purpose:  To calculate the lethal amount of a diet soda pop a person
 *           can take 
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions
const float PER_AS = .001; //the percent of artificial sweetener in a diet soda
                           //required by the problem 
//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float DtWght,  //The weight at which the dieter will stop dieting.
          NumSoda, //Number of diet soda cans that will kill the dieter.
          CvWght,  //converted weight from pounds to grams
          ArtSwtn; //The amount of artificial sweetener a person can take in gram.
    
    //Initialize Variables
    
    //Input the weight
    cout<<"This program calculates the lethal amount of the diet soda can."
            <<endl;
    cout<<"Please enter your goal weight for your diet in pounds."<<endl;
    cin>>DtWght;
    
    //Process/Map inputs to outputs
    CvWght = DtWght * 454; // 45400g = 100pounds, 454g = 1pound.
    ArtSwtn = CvWght / 7; // 1g kills 7g mouse, proportion to human.
    NumSoda = ArtSwtn/(PER_AS*350); //350g= 1 can of soda.
    //Output data
    cout<<fixed<<setprecision(0);
    cout<<"Your lethal amount of soda cans = "<<NumSoda<<" cans."<<endl;
    //Exit stage right!
    return 0;
}