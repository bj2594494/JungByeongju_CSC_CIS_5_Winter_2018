/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on January 11, 2018, 10:03 PM
 * Purpose: Calculating the calories of a bag of cookies.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    int numCkis, // The number of cookies that the user ate.
          conClrs; // The calories consumed by the user.
    
    /*Note: A bag of cookies has 30 cookies, and 10 servings. Each serving is 
            300 calories. Therefore, in each serving there are 3 cookies and by
            the proportion, each cookie is 100 calories.*/
    
    //Input the amount of cookies eaten
    cout<<"This program calculates the calories of the cookies the user ate."
        <<endl;
    cout<<"Please enter the amount of cookies you have eaten."<<endl;
    cin>>numCkis;
    //Process/Map inputs to outputs
    conClrs = numCkis*100;
    //Output data
    cout<<"You consumed "<<conClrs<<" calories."<<endl;
    //Exit stage right!
    return 0;
}

