/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on January 10, 2018, 10:05 PM
 * Purpose: Calculating the amount of ingredient needed for baking cookies.
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    float amtSgr,  // The amount of sugar needed in cups. 
          amtBttr, // The amount of butter needed in cups.
          amtFlr,  // The amount of flour needed in cups.
          numCks;  // The number of cookies the user wishes to make.
            
    //Input the number of cookies the user wishes to make.
    cout<<"This program shows the ingredients needed in baking cookies."<<endl;
    cout<<"Please enter the nuber of cookies you want to bake."<<endl;
    cin>>numCks;
    //Process/Map inputs to outputs
    amtSgr = 1.5*numCks/48;
    amtBttr = numCks/48;
    amtFlr = 2.75*numCks/48;
    //Output data
    cout<<fixed<<setprecision(2);
    cout<<"You need:"<<endl;
    cout<<amtSgr<<" cups of sugar"<<endl;
    cout<<amtBttr<<" cups of butter"<<endl;
    cout<<amtFlr<<" cups of flour"<<endl;
    //Exit stage right!
    return 0;
}

