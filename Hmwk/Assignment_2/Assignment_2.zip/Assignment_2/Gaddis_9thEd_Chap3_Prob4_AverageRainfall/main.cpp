/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on January 9, 2018, 11:56 PM
 * Purpose: Calculating average rainfall.
 */

//System Libraries
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    string MonthA, MonthB, MonthC; //The three months that the user will input.
    float RnFallA, RnFallB, RnFallC, /*The amount of rainfall for the given
                                       three months in inches.*/
          RnAvg; //The average rainfall in inches
    
    //Input the names of the months and the rain fall amounts
    cout<<"This program calculates the average amount"
            <<" of rainfall for three months"<<endl;
    
    cout<<"Enter the name of the first month."<<endl;
    cin>>MonthA;
    cout<<"Enter the amount of rainfall for "<<MonthA<<" in inches."<<endl;
    cin>>RnFallA;
    
    cout<<"Enter the name of the second month."<<endl;
    cin>>MonthB;
    cout<<"Enter the amount of rainfall for "<<MonthB<<" in inches."<<endl;
    cin>>RnFallB;
    
    cout<<"Enter the name of the third month."<<endl;
    cin>>MonthC;
    cout<<"Enter the amount of rainfall for "<<MonthC<<" in inches."<<endl;
    cin>>RnFallC;
    //Process/Map inputs to outputs
    RnAvg = (RnFallA + RnFallB + RnFallC)/3; //calculating average rainfall
    //Output data
    cout<<fixed<<setprecision(2)<<showpoint;
    cout<<"The average rainfall for "<<MonthA<<", "<<MonthB<<", and "
            <<MonthC<<" is "<<RnAvg<<" inches."<<endl;
    //Exit stage right!
    return 0;
}

