/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on January 4, 2018, 10:03 PM
 * Purpose: To calculate the total tax of $95 purchase
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    float Prchs, // Total purchase made in dollars
          StaRate, // State Sales Tax Rate  
          StatTax, // State Sales Tax
          CouRate, // County Sales Tax Rate  
          CounTax, // County Sales Tax
          TtlTax; // Total Sales Tax
    //Initialize Variables
    Prchs = 95;
    StaRate = 4;
    CouRate = 2;
    //Process/Map inputs to outputs
    StatTax = (Prchs*(StaRate/100));
    CounTax = (Prchs*(CouRate/100));
    TtlTax = StatTax + CounTax;
    //Output data
    cout<<"This program calculates the total tax";
    cout<<" of the $95 worth of purchase."<<endl;
    cout<<"Total purchase = $"<<Prchs<<endl;
    cout<<"The State Sales Tax Rate = "<<StaRate<<"%"<<endl;
    cout<<"The County Sales Tax Rate = "<<CouRate<<"%"<<endl;
    cout<<"The State Sales Tax of the purchase = $"<<StatTax<<endl;
    cout<<"The County Sales Tax of the purchase = $"<<CounTax<<endl;
    cout<<"The Total Sales Tax of the purchase = $"<<TtlTax<<endl;
    //Exit stage right!
    return 0;
}

