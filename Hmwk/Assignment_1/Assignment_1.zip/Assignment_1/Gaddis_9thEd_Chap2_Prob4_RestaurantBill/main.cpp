/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on January 4, 2018, 10:46 PM
 * Purpose: To solve the restaurant bill cost
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    float MealCst, //Cost of the meal
          Tax, //Tax of the meal 
          Tip, //Tip of the meal
          Ttle; //Total bill amount
    //Initialize Variables
    MealCst = 88.67;
    //Process/Map inputs to outputs
    Tax = MealCst*.0675;
    Tip = (MealCst + Tax)*.2;
    Ttle = MealCst + Tax + Tip;
    //Output data
    cout<<"This program calculates the tax and the tip of the $88.67";
    cout<<" worth of a meal."<<endl;
    cout<<"The cost of the meal = $"<<MealCst<<endl;
    cout<<"The tax rate = %6.75"<<endl;
    cout<<"The tax of the meal = $"<<Tax<<endl;
    cout<<"The tip rate = 20%"<<endl;
    cout<<"The tip amount = $"<<Tip<<endl;
    cout<<"Total cost of the meal = $"<<Ttle<<endl;
    //Exit stage right!
    return 0;
}

