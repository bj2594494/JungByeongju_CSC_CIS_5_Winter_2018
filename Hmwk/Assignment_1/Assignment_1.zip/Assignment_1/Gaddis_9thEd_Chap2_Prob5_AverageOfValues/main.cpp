/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on January 6, 2018, 10:40 PM
 * Purpose: Find the average for 5 given values
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    float ValueA,// First Value
          ValueB,// Second Value
          ValueC,// Third Value
          ValueD,// Fourth Value
          ValueE,// Fifth Value
          Sum,   // Sum of Five Values
          Average; // Average of Five Values
    //Initialize Variables
    ValueA = 28;
    ValueB = 32;
    ValueC = 37;
    ValueD = 24;
    ValueE = 33;
    //Process/Map inputs to outputs
    Sum = ValueA + ValueB + ValueC + ValueD + ValueE;
    Average = Sum/5;
    //Output data
    cout<<"This program shows the average of these five values."<<endl;
    cout<<"The five given values = 28,32,37,24 and 33."<<endl;
    cout<<"The sum of the given values = "<<Sum<<"."<<endl;
    cout<<"The average = "<<Average<<'.'<<endl;
    //Exit stage right!
    return 0;
}

