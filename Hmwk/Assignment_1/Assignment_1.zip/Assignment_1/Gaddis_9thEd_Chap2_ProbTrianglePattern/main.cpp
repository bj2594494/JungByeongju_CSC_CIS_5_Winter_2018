/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on January 7, 2018, 9:47 PM
 * Purpose: Create a triangle pattern
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    
    //Initialize Variables
    
    //Process/Map inputs to outputs
    
    //Output data
    cout<<"This program will create a triangle pattern."<<endl;
    cout<<"   *   "<<endl;
    cout<<"  ***  "<<endl;
    cout<<" ***** "<<endl;
    cout<<"*******"<<endl;
    //Exit stage right!
    return 0;
}

