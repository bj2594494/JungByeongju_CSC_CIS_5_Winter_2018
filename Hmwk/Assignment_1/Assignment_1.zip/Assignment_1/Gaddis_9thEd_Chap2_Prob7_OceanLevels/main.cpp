/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on January 6, 2018, 11:12 PM
 * Purpose: Calculate the amount of sea level increase in 5,7,and 10 years.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    float incRate, // Sea level increase in millimeters per year.
          fiveYr, // Sea level increase in five years.
          sevenYr, // Sea level increase in seven years.
          tenYr; // Sea level increase in ten years.
    //Initialize Variables
    incRate = 1.5;
    //Process/Map inputs to outputs
    fiveYr = incRate*5;
    sevenYr = incRate*7;
    tenYr = incRate*10;
    //Output data
    cout<<"This program shows the amount of sea level increase in ";
    cout<<"five, seven, and ten years."<<endl;
    cout<<"The sea level increase in five years = "<<fiveYr<<"mm"<<endl;
    cout<<"The sea level increase in seven years = "<<sevenYr<<"mm"<<endl;
    cout<<"The sea level increase in ten years = "<<tenYr<<"mm"<<endl;
    //Exit stage right!
    return 0;
}

