/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on January 6, 2018, 10:56 PM
 * Purpose: Calculate the annual pay.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    unsigned short payAmnt, // The amount of pay per each pay period.
          payPrds, // The number of pay period in a year.
          annlPay; // Total annual pay.
    //Initialize Variables
    payAmnt = 2200.0;
    payPrds = 26;
    //Process/Map inputs to outputs
    annlPay = payAmnt*payPrds;
    //Output data
    cout<<"This program shows the annual pay of an employee."<<endl;
    cout<<"The amount of pay the employee receives = $"<<payAmnt<<endl;
    cout<<"The number of pay period in a year = "<<payPrds<<endl;
    cout<<"The total annual pay the empolyee receives = $"<<annlPay<<endl;
    //Exit stage right!
    return 0;
}

