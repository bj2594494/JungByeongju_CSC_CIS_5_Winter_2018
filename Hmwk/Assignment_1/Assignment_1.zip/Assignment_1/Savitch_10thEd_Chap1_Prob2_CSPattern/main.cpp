/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on January 7, 2018, 10:00 PM
 * Purpose: Create CS pattern.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    
    //Initialize Variables
    
    //Process/Map inputs to outputs
    
    //Output data
    cout<<"This program shows the CS pattern."<<endl;
    cout<<"*************************************************"<<endl;
    cout<<endl;
    cout<<endl;
    cout<<"           C C C            S S S S        !!"<<endl;
    cout<<"         C       C        S         S      !!"<<endl;
    cout<<"        C                S                 !!"<<endl;
    cout<<"       C                  S                !!"<<endl;
    cout<<"       C                    S S S S        !!"<<endl;
    cout<<"       C                            S      !!"<<endl;
    cout<<"        C                            S     !!"<<endl;
    cout<<"         C       C        S         S      "<<endl;
    cout<<"           C C C            S S S S        00"<<endl;
    cout<<endl;
    cout<<endl;
    cout<<"*************************************************"<<endl;
    cout<<"    Computer Science is Cool Stuff!!!"<<endl;
    //Exit stage right!
    return 0;
}

