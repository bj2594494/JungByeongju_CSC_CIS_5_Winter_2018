/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on January 4, 2018, 9:12 PM
 * Purpose: Add 50 and 100
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    unsigned short intA, // integer 50
                   intB, // integer 100
                   total; // sum of 50 and 100
    //Initialize Variables
    intA = 50;
    intB = 100;
    //Process/Map inputs to outputs
    total = intA + intB;
    //Output data
    cout<<"This program shows the sum of 50 and 100"<<endl;
    cout<<intA<<" + "<<intB<<" = "<<total<<endl;
    //Exit stage right!
    return 0;
}

