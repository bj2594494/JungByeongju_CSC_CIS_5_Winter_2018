/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on January 6, 2018, 11:24 PM
 * Purpose: To calculate the total purchase of five given items.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    float itemA, //Price of the first item.
          itemB, //Price of the second item.
          itemC, //Price of the third item.
          itemD, //Price of the fourth item.
          itemE, //Price of the fifth item. 
          subTtl,//Subtotal amount.
          slsTax,//Sales tax amount.
          Total;//Total amount.
    //Initialize Variables
    itemA = 15.95;
    itemB = 24.95;
    itemC = 6.95;
    itemD = 12.95;
    itemE = 3.95;
    //Process/Map inputs to outputs
    subTtl = itemA + itemB + itemC + itemD+ itemE;
    slsTax = subTtl*.07;
    Total = subTtl+slsTax;
    //Output data
    cout<<"This program shows the total purchase of the";
    cout<<" given five items."<<endl;
    cout<<"The price of the first item = $"<<itemA<<endl;
    cout<<"The price of the second item = $"<<itemB<<endl;
    cout<<"The price of the third item = $"<<itemC<<endl;
    cout<<"The price of the fourth item = $"<<itemD<<endl;
    cout<<"The price of the fifth item = $"<<itemE<<endl;
    cout<<"The subtotal = $"<<subTtl<<endl;
    cout<<"The sales tax = $"<<slsTax<<endl;
    cout<<"The total amount = $"<<Total<<endl;
    //Exit stage right!
    return 0;
}

