/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on January 30, 2018, 5:52 PM
 * Purpose: Display a table that shows the rise in ocean levels.
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    float sealvl; //Sea level
    float seaInc; //Increase in sea level
    //Initialize Variables
    seaInc=1.5; //Increases 1.5 mm per year
    //Process/Map inputs to outputs
    cout<<"This program displays a table that shows the increase in"
            <<"ocean levels for next 25 years."<<endl;
    cout<<"Year  Ocean Level (mm)"<<endl;
    for(int i=1;i<=25;i++){
        sealvl=i*seaInc;
        
        cout<<setw(4)<<i
                <<"  "<<setw(5)<<"+"<<sealvl<<endl;
    }
    //Output data
    
    //Exit stage right!
    return 0;
}

