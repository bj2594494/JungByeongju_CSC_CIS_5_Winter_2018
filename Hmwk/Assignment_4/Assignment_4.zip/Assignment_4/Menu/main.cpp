/* 
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created January 31, 2018, 1:33 PM
 * Purpose:  Menu for Assignment 4
 */

//System Libraries
#include <iostream>
#include <iomanip>
#include <cstdlib>
using namespace std;

//User Libraries

//Global Constants Only!

//Function Prototypes
void Menu();
int  getN();
void def(int);
void problem1();
void problem2();
void problem3();
void problem4();
void problem5();
void problem6();
void problem7();
void problem8();
void problem9();
void problem10();

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set a Random number seed here.
    
    //Declare Main variables here.
    int inN;
    
    //Loop on each problem
    do{
        Menu();
        inN=getN();
        switch(inN){
            case 1:    problem1();break;
            case 2:    problem2();break;
            case 3:    problem3();break;
            case 4:    problem4();break;
            case 5:    problem5();break;
            case 6:    problem6();break;
            case 7:    problem7();break;
            case 8:    problem8();break;
            case 9:    problem9();break;
            case 10:   problem10();break;
            default:   def(inN);
	}
    }while(inN<11);

    //Exit Stage Right Here!
    return 0;
}

void Menu(){
    cout<<endl;
    cout<<"Type 1 to execute Gaddis_9thEd_Chap5_Prob1_SumOfNumbers."<<endl;
    cout<<"Type 2 to execute Gaddis_9thEd_Chap5_Prob3_OceanLevels."<<endl;
    cout<<"Type 3 to execute Gaddis_9thEd_Chap5_Prob4_CaloriesBurned."<<endl;
    cout<<"Type 4 to execute Gaddis_9thEd_Chap5_Prob5_MembershipFee."<<endl;
    cout<<"Type 5 to execute Gaddis_9thEd_Chap5_Prob6_DistanceTraveled."<<endl;
    cout<<"Type 6 to execute Gaddis_9thEd_Chap5_Prob7_PenniesforPay."<<endl;
    cout<<"Type 7 to execute Gaddis_9thEd_Chap5_Prob9_HotelOccupancy."<<endl;
    cout<<"Type 8 to execute Gaddis_9thEd_Chap5_Prob10_AverageRainfall."<<endl;
    cout<<"Type 9 to execute Gaddis_9thEd_Chap5_Prob19_BudgetAnalysis."<<endl;
    cout<<"Type 10 to execute Gaddis_9thEd_Chap5_Prob22_SquareDisplays."<<endl;
    cout<<"Type anything else to exit."<<endl<<endl;
}

int  getN(){
    int inN;
    cin>>inN;
    return inN;
}

void def(int inN){
    cout<<endl<<"Typing "<<inN<<" exits the program."<<endl;
}

void problem1(){
    //Declare Variables
    int number, //The number that the user will input.
        sum;    //The sum of the numbers [1,number]
    //Input data
    cout<<"This program will calculate the sum of all integers from "
            <<"1 to the number that the user chooses."<<endl;
    cout<<"Please enter a positive integer where the summation will stop."<<endl;
    cout<<"The program will end if a negative integer is entered."<<endl;
    cin>>number;
    //Process/Map inputs to outputs
    if(number>0){
        sum=0;
        for(int i=1;i<=number;i++){
            sum+=i;
            
        }
        cout<<sum<<endl;
    }
    else{
        cout<<"Invalid Entry"<<endl;
    }
}

void problem2(){
    //Declare Variables
    float sealvl; //Sea level
    float seaInc; //Increase in sea level
    //Initialize Variables
    seaInc=1.5; //Increases 1.5 mm per year
    //Process/Map inputs to outputs
    cout<<"This program displays a table that shows the increase in"
            <<"ocean levels for next 25 years."<<endl;
    cout<<"Year  Ocean Level (mm)"<<endl;
    for(int i=1;i<=25;i++){
        sealvl=i*seaInc;
        
        cout<<setw(4)<<i
                <<"  "<<setw(5)<<"+"<<sealvl<<endl;
    }
}

void problem3(){
    //Declare Variables
    float calBrnd, //Total calories burned
          calDecr; //Calories burned per minute
    //Initialize Variables
    calDecr=18;   //3.6 Calories burned per minute*5= 18 calories per 5 minutes
    //Process/Map inputs to outputs
    cout<<"This program displays calories burned on a treadmill"<<endl;
    cout<<"Minutes Ran    :  5 min  10 min  15 min  20 min  25 min  30 min"<<endl;
    cout<<"Calories Burned:";
    for(int i=1;i<=6;i++){
        calBrnd=calDecr*i;
        cout<<" "<<calBrnd<<" cal ";
    }
    cout<<endl<<endl;
}

void problem4(){
    //Declare Variables
    float member,  //Membership cost in $'s
          intCost, //Initial membership cost in $'s
          memRate, //Increase rate in membership per year
          memInc;  //Increased cost in $'s
    //Initialize Variables
    intCost=2500;
    memRate=.04;
    //Process/Map inputs to outputs
    cout<<"This program displays the increase in the membership cost per year"
            <<" for next 6 years."<<endl;
    cout<<"Initial Membership Cost = $2500.00"<<endl;
    for(int i=1;i<=6;i++){
        memInc=intCost*memRate;
        member=intCost+memInc;
        intCost=member;
        cout<<fixed<<setprecision(2);
        cout<<"Year "<<i<<" $"<<memInc<<" Increase"
                <<"    Membership Cost = "<<"$"
                <<member<<endl;
    }
}

void problem5(){
    //Declare Variables
    float speed,    //Input value for speed in miles per hour
        hours,    //Input value for hours traveled
        distance; //Total distance traveled
    //Input Values
    cout<<"This program calculates the distance traveled."<<endl;
    cout<<"Please enter the speed the vehicle was traveling at."<<endl;
    cout<<"Do not put negative value."<<endl;
    cin>>speed;
    if(speed<0){
        cout<<"Invalid Entry";
        exit(0);
    }
    cout<<"Please enter the hour(s) traveled."<<endl;
    cout<<"Do not put hour(s) less than 1."<<endl;
    cin>>hours;
    if(hours<1){
        cout<<"Invalid Entry";
        exit(0);
    }
    //Process/Map inputs to outputs and output data
    cout<<"Hours      Distance Traveled"<<endl;
    cout<<"---------------------------"<<endl;
    for(int i=1;i<=hours;i++){
        distance=i*speed;
        cout<<setw(3)<<i<<"      "<<setw(12)<<distance<<endl;
    }
}

void problem6(){
    //Declare Variables
    float days,    //Input Value for days worked
          penny,   //first day pay 
          dayPay,  //Pay for that specific day
          totPay;  //Total pay
    
    //Initialize Value
    penny=.01;
    totPay=0;
    //Input Value
    cout<<"This program calculates the total pay for the pennies for day."<<endl;
    cout<<"Please enter the day(s) worked."<<endl;
    cout<<"Do not enter a value less than 1."<<endl;
    cin>>days;
    if(days<1){
        cout<<"Invalid Entry."<<endl;
        exit(0);
    }
    //Process/Map inputs to outputs
    cout<<"Day   Salary   Total"<<endl;
    for(int i=1;i<=days;i++){
        dayPay=penny;
        penny*=2;
        totPay+=dayPay;
        cout<<fixed<<setprecision(2);
        cout<<i<<"     "<<"$"<<dayPay
            <<"    "<<"$"<<totPay<<endl;
    }
}

void problem7(){
    //Declare Variables
    int   floors,  //Total floors
          rooms,   //Number of rooms in each floor
          ocRooms; //Occupied rooms in each floor
    float ttlRoom, //Total rooms the hotel has
          ttlOccu, //Total occupied rooms the hotel has
          perOccu; //Percent of occupied rooms
    
    //Initialize values
    ttlRoom=0;
    ttlOccu=0;
    
    //Input Values
    cout<<"This program calculates the hotel occupancy."<<endl;
    cout<<"Please enter the total number of floors the hotel has."<<endl;
    cout<<"Do not enter a value less than 1."<<endl;
    cin>>floors;
    if(floors<1){
        cout<<"Invalid Entry"<<endl;
        exit(0);
    }
    
    //Process/Map inputs to output
        for(int i=1;i<=floors;i++){ 
            if(i<13){  //floor 13 will be skipped
                cout<<"Please enter the total number of rooms the floor "
                        <<i<<" has."<<endl;
            }
            else if(i>=13){
                cout<<"Please enter the total number of rooms the floor "
                        <<i+1<<" has."<<endl;
            }
            cout<<"Do not enter a value less than 10."<<endl;
            cin>>rooms;
                if(rooms<10){
                cout<<"Invalid Entry"<<endl;
                exit(0);
            }

            if(i<13){  //floor 13 will be skipped
                cout<<"Please enter the total number of occupied rooms the floor "
                    <<i<<" has."<<endl;
            }
            else if(i>=13){
                cout<<"Please enter the total number of occupied rooms the floor "
                    <<i+1<<" has."<<endl;
            }
            
            cin>>ocRooms;

            ttlRoom+=rooms;
            ttlOccu+=ocRooms;
        }
    


    perOccu=(ttlOccu/ttlRoom)*100;
    
    //Output data
    cout<<"Total Rooms                  = "<<ttlRoom<<endl;
    cout<<"Total Unoccupied Rooms       = "<<ttlRoom-ttlOccu<<endl;
    cout<<"Total Occupied Rooms         = "<<ttlOccu<<endl;
    cout<<fixed<<setprecision(2);
    cout<<"Percentage of Rooms Occupied = "<<perOccu<<"%"<<endl;
}

void problem8(){
    //Declare Variables
    float year,    //The total periods in years.
        inRain,  //Total rainfall for that month.
        ttlMnth, //Total months in the given period.
        ttlRain, //Total rain in the given period.
        avrRain; //Average rainfall.
    //Initialize Variables
    ttlRain=0;
    //Input Values
    cout<<"This program calculates the rainfall."<<endl;
    cout<<"Enter the period in years."<<endl;
    cout<<"Do not enter value less than 1."<<endl;
    cin>>year;
    if(year<1){
        cout<<"Invalid Entry"<<endl;
        exit(0);
    }
    //Process/Map inputs to outputs
    for(int i=1;i<=year;i++){
        for(int n=1;n<=12;n++){
            cout<<"Please enter the amount of rainfall for month "
                    <<n<<" in year "<<i<<endl;
            cout<<"Do not enter a negative value."<<endl;
            cin>>inRain;
                if(inRain<0){
                cout<<"Invalid Entry"<<endl;
                exit(0);
                }
            ttlRain+=inRain;
        }
        avrRain=ttlRain/(12*year);
        
    }
    //Output data
    cout<<fixed<<setprecision(1);
    cout<<"The average rainfall                   = "<<avrRain<<" in."<<endl;
    cout<<fixed<<setprecision(0);
    cout<<"The total number of months             = "<<year*12<<endl;
    cout<<fixed<<setprecision(1);
    cout<<"The total rainfall in the given period = "<<ttlRain
            <<" in."<<endl;

}

void problem9(){
    //Declare Variables
    float budget, //Monthly Budget amount
          rnTotal,//Running Total
          expense;//Expenses the user uses
    //Initialize Variables
    rnTotal=0;
    
    //Input Values
    cout<<"This program shows budget analysis."<<endl;
    cout<<"Enter your monthly budget."<<endl;
    cin>>budget;
    cout<<"Enter your expenses one by one in $'s."<<endl;
    //Process/Map inputs to outputs
    do{
        cin>>expense;
        rnTotal+=expense;
        cout<<"Current running total = $"<<rnTotal<<endl;
    }while (!(expense==0));
    //Output data
    if(rnTotal>budget)
        cout<<"You are over your budget by $"<<rnTotal-budget
                <<"."<<endl;
    else if(rnTotal<budget)
        cout<<"You are under your budget by $"<<budget-rnTotal
                <<"."<<endl;
    else
        cout<<"You are exactly on your budget. $0 left on your budget."<<endl;
}

void problem10(){
    //Declare Variables
    int sdLngth; //Length/Width of a square
    //Initialize Variables
    
    //Input Value
    cout<<"This program displays sqaure pattern."<<endl;
    cout<<"Please enter a positive integer between 1-15."<<endl;
    cin>>sdLngth;
    //Process/Map inputs to outputs
    for(int i=1;i<=sdLngth;i++){
        for(int n=1;n<=sdLngth;n++){
            cout<<"X";
        }
        cout<<endl;
    }
}