/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on January 30, 2018, 9:09 PM
 * Purpose: Calculating the average rainfall
 */

//System Libraries
#include <iostream>
#include <cstdlib>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    float year,    //The total periods in years.
        inRain,  //Total rainfall for that month.
        ttlMnth, //Total months in the given period.
        ttlRain, //Total rain in the given period.
        avrRain; //Average rainfall.
    //Initialize Variables
    ttlRain=0;
    //Input Values
    cout<<"This program calculates the rainfall."<<endl;
    cout<<"Enter the period in years."<<endl;
    cout<<"Do not enter value less than 1."<<endl;
    cin>>year;
    if(year<1){
        cout<<"Invalid Entry"<<endl;
        exit(0);
    }
    //Process/Map inputs to outputs
    for(int i=1;i<=year;i++){
        for(int n=1;n<=12;n++){
            cout<<"Please enter the amount of rainfall for month "
                    <<n<<" in year "<<i<<endl;
            cout<<"Do not enter a negative value."<<endl;
            cin>>inRain;
                if(inRain<0){
                cout<<"Invalid Entry"<<endl;
                exit(0);
                }
            ttlRain+=inRain;
        }
        avrRain=ttlRain/36;
        
    }
    //Output data
    cout<<fixed<<setprecision(1);
    cout<<"The average rainfall                 = "<<avrRain<<" in."<<endl;
    cout<<fixed<<setprecision(0);
    cout<<"The total number of months           = "<<year*12<<endl;
    cout<<fixed<<setprecision(1);
    cout<<"The total rainfall in the given period = "<<ttlRain
            <<" in."<<endl;
    //Exit stage right!
    return 0;
}

