/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on January 30, 2018, 11:08 PM
 * Purpose: Budget Analysis
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    float budget, //Monthly Budget amount
          rnTotal,//Running Total
          expense;//Expenses the user uses
    //Initialize Variables
    rnTotal=0;
    
    //Input Values
    cout<<"This program shows budget analysis."<<endl;
    cout<<"Enter your monthly budget."<<endl;
    cin>>budget;
    cout<<"Enter your expenses one by one in $'s."<<endl;
    //Process/Map inputs to outputs
    do{
        cin>>expense;
        rnTotal+=expense;
        cout<<"Current running total = $"<<rnTotal<<endl;
    }while (!(expense==0));
    //Output data
    if(rnTotal>budget)
        cout<<"You are over your budget by $"<<rnTotal-budget
                <<"."<<endl;
    else if(rnTotal<budget)
        cout<<"You are under your budget by $"<<budget-rnTotal
                <<"."<<endl;
    else
        cout<<"You are exactly on your budget. $0 left on your budget."<<endl;
    //Exit stage right!
    return 0;
}

