/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on January 30, 2018, 6:42 PM
 * Purpose: Calculating increase in membership fee
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    float member,  //Membership cost in $'s
          intCost, //Initial membership cost in $'s
          memRate, //Increase rate in membership per year
          memInc;  //Increased cost in $'s
    //Initialize Variables
    intCost=2500;
    memRate=.04;
    //Process/Map inputs to outputs
    cout<<"This program displays the increase in the membership cost per year."
            <<endl;
    for(int i=1;i<=6;i++){
        memInc=intCost*memRate;
        member=intCost+memInc;
        intCost=member;
        cout<<fixed<<setprecision(2);
        cout<<"Year "<<i<<" $"<<memInc<<" Increase"
                <<"    Membership Cost = "<<"$"
                <<member<<endl;
    }
    //Output data
    
    //Exit stage right!
    return 0;
}

