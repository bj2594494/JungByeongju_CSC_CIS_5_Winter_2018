/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on January 30, 2018, 11:50 PM
 * Purpose: Display a square pattern
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    int sdLngth; //Length/Width of a square
    //Initialize Variables
    
    //Input Value
    cout<<"This program displays sqaure pattern."<<endl;
    cout<<"Please enter a positive integer between 1-15."<<endl;
    cin>>sdLngth;
    //Process/Map inputs to outputs
    for(int i=1;i<=sdLngth;i++){
        for(int n=1;n<=sdLngth;n++){
            cout<<"X";
        }
        cout<<endl;
    }
    //Output data
    
    //Exit stage right!
    return 0;
}

