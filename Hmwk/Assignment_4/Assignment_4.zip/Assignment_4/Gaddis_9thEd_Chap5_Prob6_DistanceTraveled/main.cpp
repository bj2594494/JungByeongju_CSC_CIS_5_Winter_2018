/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on January 3, 2018, 7:02 PM
 * Purpose: Calculate Distance Traveled
 */

//System Libraries
#include <iostream>
#include <iomanip>
#include <cstdlib>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    float speed,    //Input value for speed in miles per hour
        hours,    //Input value for hours traveled
        distance; //Total distance traveled
    //Input Values
    cout<<"This program calculates the distance traveled."<<endl;
    cout<<"Please enter the speed the vehicle was traveling at."<<endl;
    cout<<"Do not put negative value."<<endl;
    cin>>speed;
    if(speed<0){
        cout<<"Invalid Entry";
        exit(0);
    }
    cout<<"Please enter the hour(s) traveled."<<endl;
    cout<<"Do not put hour(s) less than 1."<<endl;
    cin>>hours;
    if(hours<1){
        cout<<"Invalid Entry";
        exit(0);
    }
    //Process/Map inputs to outputs and output data
    cout<<"Hours      Distance Traveled"<<endl;
    cout<<"---------------------------"<<endl;
    for(int i=1;i<=hours;i++){
        distance=i*speed;
        cout<<setw(3)<<i<<"      "<<setw(12)<<distance<<endl;
    }
    
    
    //Exit stage right!
    return 0;
}

