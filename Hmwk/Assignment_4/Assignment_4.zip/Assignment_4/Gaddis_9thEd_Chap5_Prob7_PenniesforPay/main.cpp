/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on January 30, 2018, 7:20 PM
 * Purpose: Calculating pennies for pay problem
 */

//System Libraries
#include <iostream>
#include <cstdlib>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    float days,    //Input Value for days worked
          penny,   //first day pay 
          dayPay,  //Pay for that specific day
          totPay;  //Total pay
    
    //Initialize Value
    penny=.01;
    totPay=0;
    //Input Value
    cout<<"This program calculates the total pay for the pennies for day."<<endl;
    cout<<"Please enter the day(s) worked."<<endl;
    cout<<"Do not enter a value less than 1."<<endl;
    cin>>days;
    if(days<1){
        cout<<"Invalid Entry."<<endl;
        exit(0);
    }
    //Process/Map inputs to outputs
    cout<<"Day   Salary   Total"<<endl;
    for(int i=1;i<=days;i++){
        dayPay=penny;
        penny*=2;
        totPay+=dayPay;
        cout<<fixed<<setprecision(2);
        cout<<i<<"     "<<"$"<<dayPay
            <<"    "<<"$"<<totPay<<endl;
    }
    //Output data
    
    //Exit stage right!
    return 0;
}

