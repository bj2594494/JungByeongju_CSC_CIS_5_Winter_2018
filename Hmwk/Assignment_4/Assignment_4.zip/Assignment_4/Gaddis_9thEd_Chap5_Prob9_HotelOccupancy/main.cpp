/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on January 30, 2018, 7:51 PM
 * Purpose: Hotel Occupancy Problem
 */

//System Libraries
#include <iostream>
#include <cstdlib>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    int   floors,  //Total floors
          rooms,   //Number of rooms in each floor
          ocRooms; //Occupied rooms in each floor
    float ttlRoom, //Total rooms the hotel has
          ttlOccu, //Total occupied rooms the hotel has
          perOccu; //Percent of occupied rooms
    
    //Initialize values
    ttlRoom=0;
    ttlOccu=0;
    
    //Input Values
    cout<<"This program calculates the hotel occupancy."<<endl;
    cout<<"Please enter the total number of floors the hotel has."<<endl;
    cout<<"Do not enter a value less than 1."<<endl;
    cin>>floors;
    if(floors<1){
        cout<<"Invalid Entry"<<endl;
        exit(0);
    }
    
    //Process/Map inputs to output
        for(int i=1;i<=floors;i++){ 
            if(i<13){  //floor 13 will be skipped
                cout<<"Please enter the total number of rooms the floor "
                        <<i<<" has."<<endl;
            }
            else if(i>=13){
                cout<<"Please enter the total number of rooms the floor "
                        <<i+1<<" has."<<endl;
            }
            cout<<"Do not enter a value less than 10."<<endl;
            cin>>rooms;
                if(rooms<10){
                cout<<"Invalid Entry"<<endl;
                exit(0);
            }

            if(i<13){  //floor 13 will be skipped
                cout<<"Please enter the total number of occupied rooms the floor "
                    <<i<<" has."<<endl;
            }
            else if(i>=13){
                cout<<"Please enter the total number of occupied rooms the floor "
                    <<i+1<<" has."<<endl;
            }
            
            cin>>ocRooms;

            ttlRoom+=rooms;
            ttlOccu+=ocRooms;
        }
    


    perOccu=(ttlOccu/ttlRoom)*100;
    
    //Output data
    cout<<"Total Rooms                  = "<<ttlRoom<<endl;
    cout<<"Total Unoccupied Rooms       = "<<ttlRoom-ttlOccu<<endl;
    cout<<"Total Occupied Rooms         = "<<ttlOccu<<endl;
    cout<<fixed<<setprecision(2);
    cout<<"Percentage of Rooms Occupied = "<<perOccu<<"%"<<endl;
    
    //Exit stage right!
    return 0;
}

