/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on January 30, 2018, 6:20 PM
 * Purpose: Calories Burned
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    float calBrnd, //Total calories burned
          calDecr; //Calories burned per minute
    //Initialize Variables
    calDecr=18;   //3.6 Calories burned per minute*5= 18 calories per 5 minutes
    //Process/Map inputs to outputs
    cout<<"This program displays calories burned on a treadmill"<<endl;
    cout<<"Minutes Ran    :  5 min  10 min  15 min  20 min  25 min  30 min"<<endl;
    cout<<"Calories Burned:";
    for(int i=1;i<=6;i++){
        calBrnd=calDecr*i;
        cout<<" "<<calBrnd<<" cal ";
    }
    //Output data
    
    //Exit stage right!
    return 0;
}

