/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on January 29, 2018, 9:20 PM
 * Purpose: Sum of Numbers using Loops
 */

//System Libraries
#include <iostream>
#include <cstdlib>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    int number, //The number that the user will input.
        sum;    //The sum of the numbers [1,number]
    //Input data
    cout<<"This program will calculate the sum of all integers from "
            <<"1 to the number that the user chooses."<<endl;
    cout<<"Please enter a positive integer where the summation will stop."<<endl;
    cout<<"The program will end if a negative integer is entered."<<endl;
    cin>>number;
    //Process/Map inputs to outputs
    if(number>0){
        sum=0;
        for(int i=1;i<=number;i++){
            sum+=i;
            
        }
        cout<<sum<<endl;
    }
    else{
        cout<<"Invalid Entry"<<endl;
    }
        

    
    //Exit stage right!
    return 0;
}

